﻿using Dll.BL;
using Dll.DL;
using Inventory.Forms.Seller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory.Forms
{
    public partial class ItemDetailsBuyerForm : Form
    {
        public ItemDetailsBuyerForm()
        {
            InitializeComponent();
        }

        private void PopulateLabels()
        {
            Item item = this.Tag.GetType().GetProperty("Payload").GetValue(this.Tag) as Item;
            NameLabel.Text = item.Name;
            DescriptionLabel.Text = item.Description;
            PriceLabel.Text = item.Price.ToString();
            QuantityLabel.Text = item.Quantity.ToString();
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            BuyerForm form = this.Tag.GetType().GetProperty("Parent").GetValue(this.Tag) as BuyerForm;
            form.OpenChildForm(new VisitMarketPlaceForm());
        }

        private void ItemDetailsForm_Load(object sender, EventArgs e)
        {
            PopulateLabels();
        }

        private void CartButton_Click(object sender, EventArgs e)
        {
            BuyerForm form = this.Tag.GetType().GetProperty("Parent").GetValue(this.Tag) as BuyerForm;
            Item item = this.Tag.GetType().GetProperty("Payload").GetValue(this.Tag) as Item;
            DialogResult dialogResult = MessageBox.Show("Do You Want to Add this Item to Cart?", "Add Item to Cart", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Order order = new Order(item, 1);
                form.SessionBuyer.AddOrder(order);
                item.Purchase(1);
                UserCRUD.RewriteUsers();
                MessageBox.Show("Item Added To the Cart Successfully!");
                form.OpenChildForm(new VisitMarketPlaceForm());
            }
        }

        private void OrderButton_Click(object sender, EventArgs e)
        {
            BuyerForm form = this.Tag.GetType().GetProperty("Parent").GetValue(this.Tag) as BuyerForm;
            Item item = this.Tag.GetType().GetProperty("Payload").GetValue(this.Tag) as Item;
            DialogResult dialogResult = MessageBox.Show("Do You Want to Place Order for this Item?", "Place Order", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Order order = new Order(item, 1);
                CheckOut checkOut = new CheckOut(order);
                form.SessionBuyer.AddCheckOut(checkOut);
                item.Purchase(1);
                UserCRUD.RewriteUsers();
                MessageBox.Show("Order Placed Successfully!");
                form.OpenChildForm(new VisitMarketPlaceForm());
            }
        }

        private void NameLabel_Click(object sender, EventArgs e)
        {

        }

        private void DescriptionLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
