﻿namespace Inventory.Forms
{
    partial class BuyerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.sideBar = new System.Windows.Forms.Panel();
            this.LogOutButton = new FontAwesome.Sharp.IconButton();
            this.NotificationsBtn = new FontAwesome.Sharp.IconButton();
            this.TrackOrderBtn = new FontAwesome.Sharp.IconButton();
            this.ViewCartBtn = new FontAwesome.Sharp.IconButton();
            this.VisitMarketPlaceBtn = new FontAwesome.Sharp.IconButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buyerChangeAble = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.sideBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).BeginInit();
            this.buyerChangeAble.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.sideBar, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1200, 692);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // sideBar
            // 
            this.sideBar.BackColor = System.Drawing.Color.DimGray;
            this.sideBar.Controls.Add(this.LogOutButton);
            this.sideBar.Controls.Add(this.NotificationsBtn);
            this.sideBar.Controls.Add(this.TrackOrderBtn);
            this.sideBar.Controls.Add(this.ViewCartBtn);
            this.sideBar.Controls.Add(this.VisitMarketPlaceBtn);
            this.sideBar.Controls.Add(this.pictureBox1);
            this.sideBar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sideBar.Location = new System.Drawing.Point(0, 0);
            this.sideBar.Margin = new System.Windows.Forms.Padding(0);
            this.sideBar.Name = "sideBar";
            this.sideBar.Size = new System.Drawing.Size(250, 692);
            this.sideBar.TabIndex = 2;
            this.sideBar.Paint += new System.Windows.Forms.PaintEventHandler(this.sideBar_Paint);
            // 
            // LogOutButton
            // 
            this.LogOutButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.LogOutButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LogOutButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.LogOutButton.FlatAppearance.BorderSize = 0;
            this.LogOutButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LogOutButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogOutButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.LogOutButton.IconChar = FontAwesome.Sharp.IconChar.PowerOff;
            this.LogOutButton.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.LogOutButton.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.LogOutButton.IconSize = 28;
            this.LogOutButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LogOutButton.Location = new System.Drawing.Point(0, 632);
            this.LogOutButton.Name = "LogOutButton";
            this.LogOutButton.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.LogOutButton.Size = new System.Drawing.Size(250, 60);
            this.LogOutButton.TabIndex = 6;
            this.LogOutButton.Text = "       Log Out";
            this.LogOutButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LogOutButton.UseVisualStyleBackColor = false;
            this.LogOutButton.Click += new System.EventHandler(this.LogOutButton_Click);
            // 
            // NotificationsBtn
            // 
            this.NotificationsBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.NotificationsBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NotificationsBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.NotificationsBtn.FlatAppearance.BorderSize = 0;
            this.NotificationsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NotificationsBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NotificationsBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.NotificationsBtn.IconChar = FontAwesome.Sharp.IconChar.Bell;
            this.NotificationsBtn.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.NotificationsBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.NotificationsBtn.IconSize = 28;
            this.NotificationsBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NotificationsBtn.Location = new System.Drawing.Point(0, 372);
            this.NotificationsBtn.Name = "NotificationsBtn";
            this.NotificationsBtn.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.NotificationsBtn.Size = new System.Drawing.Size(250, 70);
            this.NotificationsBtn.TabIndex = 4;
            this.NotificationsBtn.Text = "       Notifications";
            this.NotificationsBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NotificationsBtn.UseVisualStyleBackColor = false;
            this.NotificationsBtn.Click += new System.EventHandler(this.NotificationsBtn_Click);
            // 
            // TrackOrderBtn
            // 
            this.TrackOrderBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TrackOrderBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TrackOrderBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.TrackOrderBtn.FlatAppearance.BorderSize = 0;
            this.TrackOrderBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TrackOrderBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrackOrderBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.TrackOrderBtn.IconChar = FontAwesome.Sharp.IconChar.Box;
            this.TrackOrderBtn.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.TrackOrderBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.TrackOrderBtn.IconSize = 28;
            this.TrackOrderBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.TrackOrderBtn.Location = new System.Drawing.Point(0, 316);
            this.TrackOrderBtn.Name = "TrackOrderBtn";
            this.TrackOrderBtn.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.TrackOrderBtn.Size = new System.Drawing.Size(250, 56);
            this.TrackOrderBtn.TabIndex = 3;
            this.TrackOrderBtn.Text = "       Track Order";
            this.TrackOrderBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.TrackOrderBtn.UseVisualStyleBackColor = false;
            this.TrackOrderBtn.Click += new System.EventHandler(this.TrackOrderBtn_Click);
            // 
            // ViewCartBtn
            // 
            this.ViewCartBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ViewCartBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ViewCartBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.ViewCartBtn.FlatAppearance.BorderSize = 0;
            this.ViewCartBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ViewCartBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewCartBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.ViewCartBtn.IconChar = FontAwesome.Sharp.IconChar.ShoppingCart;
            this.ViewCartBtn.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.ViewCartBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ViewCartBtn.IconSize = 28;
            this.ViewCartBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ViewCartBtn.Location = new System.Drawing.Point(0, 254);
            this.ViewCartBtn.Name = "ViewCartBtn";
            this.ViewCartBtn.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.ViewCartBtn.Size = new System.Drawing.Size(250, 62);
            this.ViewCartBtn.TabIndex = 2;
            this.ViewCartBtn.Text = "       View Cart";
            this.ViewCartBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ViewCartBtn.UseVisualStyleBackColor = false;
            this.ViewCartBtn.Click += new System.EventHandler(this.ViewCartBtn_Click);
            // 
            // VisitMarketPlaceBtn
            // 
            this.VisitMarketPlaceBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.VisitMarketPlaceBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.VisitMarketPlaceBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.VisitMarketPlaceBtn.FlatAppearance.BorderSize = 0;
            this.VisitMarketPlaceBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.VisitMarketPlaceBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VisitMarketPlaceBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.VisitMarketPlaceBtn.IconChar = FontAwesome.Sharp.IconChar.Store;
            this.VisitMarketPlaceBtn.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.VisitMarketPlaceBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.VisitMarketPlaceBtn.IconSize = 28;
            this.VisitMarketPlaceBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.VisitMarketPlaceBtn.Location = new System.Drawing.Point(0, 208);
            this.VisitMarketPlaceBtn.Name = "VisitMarketPlaceBtn";
            this.VisitMarketPlaceBtn.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.VisitMarketPlaceBtn.Size = new System.Drawing.Size(250, 46);
            this.VisitMarketPlaceBtn.TabIndex = 1;
            this.VisitMarketPlaceBtn.Text = "       Visit Market ";
            this.VisitMarketPlaceBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.VisitMarketPlaceBtn.UseVisualStyleBackColor = false;
            this.VisitMarketPlaceBtn.Click += new System.EventHandler(this.VisitMarketPlaceBtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Image = global::Inventory.Properties.Resources._360_F_541022338_YBWUEqRTPExosIPtHH7b8ZHQuclW4unG;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(250, 208);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.buyerChangeAble, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(250, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(950, 692);
            this.tableLayoutPanel2.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.iconPictureBox1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 632);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(950, 60);
            this.panel1.TabIndex = 3;
            // 
            // iconPictureBox1
            // 
            this.iconPictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.iconPictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Dungeon;
            this.iconPictureBox1.IconColor = System.Drawing.Color.White;
            this.iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox1.IconSize = 60;
            this.iconPictureBox1.Location = new System.Drawing.Point(354, 5);
            this.iconPictureBox1.Name = "iconPictureBox1";
            this.iconPictureBox1.Size = new System.Drawing.Size(60, 60);
            this.iconPictureBox1.TabIndex = 1;
            this.iconPictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(426, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 29);
            this.label2.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(406, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 48);
            this.label1.TabIndex = 1;
            this.label1.Text = "Inventory";
            // 
            // buyerChangeAble
            // 
            this.buyerChangeAble.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buyerChangeAble.Controls.Add(this.pictureBox2);
            this.buyerChangeAble.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buyerChangeAble.Location = new System.Drawing.Point(0, 0);
            this.buyerChangeAble.Margin = new System.Windows.Forms.Padding(0);
            this.buyerChangeAble.Name = "buyerChangeAble";
            this.buyerChangeAble.Size = new System.Drawing.Size(950, 632);
            this.buyerChangeAble.TabIndex = 2;
            this.buyerChangeAble.Paint += new System.Windows.Forms.PaintEventHandler(this.buyerChangeAble_Paint);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Default;
            this.pictureBox2.Image = global::Inventory.Properties.Resources._360_F_542850615_1B16r8qsUa5oR8zq4td8wqi911uczewS;
            this.pictureBox2.Location = new System.Drawing.Point(91, 135);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(806, 494);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // BuyerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(75)))), ((int)(((byte)(96)))));
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "BuyerForm";
            this.Text = "Buyer Menu";
            this.Load += new System.EventHandler(this.BuyerForm_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.sideBar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).EndInit();
            this.buyerChangeAble.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel sideBar;
        private FontAwesome.Sharp.IconButton LogOutButton;
        private FontAwesome.Sharp.IconButton NotificationsBtn;
        private FontAwesome.Sharp.IconButton TrackOrderBtn;
        private FontAwesome.Sharp.IconButton ViewCartBtn;
        private FontAwesome.Sharp.IconButton VisitMarketPlaceBtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel buyerChangeAble;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}