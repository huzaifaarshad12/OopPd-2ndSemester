﻿using Dll.BL;
using Dll.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory.Forms
{
    public partial class AddItemForm : Form
    {
        private SellerUser Seller;
        public AddItemForm()
        {
            InitializeComponent();
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            string itemName = NameText.Text;
            string itemDescription = DescriptionText.Text;
            double itemPrice = double.Parse(PriceText.Text);
            int itemQuantity = int.Parse(QuantityText.Text);
            Item item = new Item(itemName, itemDescription, itemPrice, itemQuantity, Seller.FullName);
            Seller.AddItem(item);
            UserCRUD.RewriteUsers();
            MessageBox.Show("Item Added Successfully");
            NameText.Text = "";
            DescriptionText.Text = "";
            PriceText.Text = "";
            QuantityText.Text = "";
        }

        private void AddItemForm_Load(object sender, EventArgs e)
        {
            Seller = ((SellerForm)Tag).SessionSeller;
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
