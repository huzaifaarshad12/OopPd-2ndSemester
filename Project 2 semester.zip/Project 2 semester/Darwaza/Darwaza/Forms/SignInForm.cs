﻿using Dll.BL;
using Dll.DL;
using Inventory.Forms.LoginPage;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory.Forms
{
    public partial class SignInForm : Form
    {
        public SignInForm()
        {
            InitializeComponent();
        }
        private void SignUpBtn_Click(object sender, EventArgs e)
        {
            LoginPageForm form = this.Tag as LoginPageForm;
            form.OpenChildForm(new SignUpForm());
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            string userName = UserNameLabel.Text;
            string password = PasswordLabel.Text;
            User user = UserCRUD.FindUser(userName, password);
            if (user != null)
            {
                MainForm form = ((Form)this.Tag).Tag as MainForm;
                form.SessionUser = user;
                if (user is SellerUser)
                {
                    form.OpenChildForm(new SellerForm());
                }
                else if (user is BuyerUser)
                {
                    form.OpenChildForm(new BuyerForm());
                }
            }
            else
            {
                MessageBox.Show("Incorrect Username/Password");
                UserNameLabel.Clear();
                PasswordLabel.Clear();
            }
        }

        private void SignInForm_Load(object sender, EventArgs e)
        {
            PasswordLabel.PasswordChar = '\u25CF';
        }
    }
}
