﻿using Dll.BL;
using Dll.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Inventory.Forms.Seller
{
    public partial class UpdateItemDetailsForm : Form
    {
        public UpdateItemDetailsForm()
        {
            InitializeComponent();
        }
        private void PopulateTextBoxes()
        {
            Item item = this.Tag.GetType().GetProperty("Payload").GetValue(this.Tag) as Item;
            NameTextBox.Text = item.Name;
            DescriptionTextBox.Text = item.Description;
            PriceTextBox.Text = item.Price.ToString();
            QuantityTextBox.Text = item.Quantity.ToString();
        }
        private void UpdateItemDetailsForm_Load(object sender, EventArgs e)
        {
            PopulateTextBoxes();
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            Item item = this.Tag.GetType().GetProperty("Payload").GetValue(this.Tag) as Item;
            SellerForm form = this.Tag.GetType().GetProperty("Parent").GetValue(this.Tag) as SellerForm;
            Form childForm = this.Tag.GetType()?.GetProperty("Child")?.GetValue(this.Tag) as Form;
            item.Name = NameTextBox.Text;
            item.Description = DescriptionTextBox.Text;
            item.Price = double.Parse(PriceTextBox.Text);
            item.Quantity = int.Parse(QuantityTextBox.Text);
            MessageBox.Show("Item Updated Successfully");
            UserCRUD.RewriteUsers();
            if (childForm != null)
            {
                form.OpenChildForm(childForm, item);
            }
            else
            {
                form.OpenChildForm(new UpdateItemForm());
            }
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
