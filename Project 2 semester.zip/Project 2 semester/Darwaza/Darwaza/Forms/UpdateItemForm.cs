﻿using Dll.BL;
using Dll.DL;
using Inventory.Forms.Seller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory.Forms
{
    public partial class UpdateItemForm : Form
    {
        private SellerUser Seller;
        private List<Item> items;
        public UpdateItemForm()
        {
            InitializeComponent();
        }

        private void DataBind(List<Item> items)
        {
            ItemsGrid.DataSource = new BindingList<Item>(items);
        }

        private void SearchItem()
        {
            string query = ItemSearchBar.Text;
            BindingList<Item> source = (BindingList<Item>)ItemsGrid.DataSource;
            List<Item> searchedItems = source.Where(item => item.Name.StartsWith(query)).ToList();
            DataBind(searchedItems);
        }

        private void ItemSearchBar_TextChanged(object sender, EventArgs e)
        {
            if (ItemSearchBar.Text == "")
            {
                DataBind(items);
            }
            else
            {
                SearchItem();
            }
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UpdateItemForm_Load(object sender, EventArgs e)
        {
            Seller = ((SellerForm)Tag).SessionSeller;
            items = Seller.Items;
            DataBind(items);
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            int itemIndex = GetSelectedRow();
            if (itemIndex == -1) return;
            Item item = Seller.GetItem(itemIndex);
            SellerForm sellerForm = this.Tag as SellerForm;
            UpdateItemDetailsForm updateItemDetailsForm = new UpdateItemDetailsForm();
            sellerForm.OpenChildForm(updateItemDetailsForm, item);
        }

        private int GetSelectedRow()
        {
            int index;
            if (ItemsGrid.SelectedCells.Count > 0)
            {
                index = ItemsGrid.SelectedCells[0].RowIndex;
            }
            else
            {
                index = -1;
            }
            return index;
        }
    }
}
