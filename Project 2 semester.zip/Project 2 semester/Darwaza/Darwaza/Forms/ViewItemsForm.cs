﻿using Dll.BL;
using Dll.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory.Forms
{
    public partial class ViewItemsForm : Form
    {
        private SellerUser Seller;
        private List<Item> items;
        public ViewItemsForm()
        {
            InitializeComponent();
        }
        private void DataBind()
        {
            ItemsGrid.DataSource = new BindingList<Item>(items);
        }

        private void SearchItem()
        {
            string query = ItemSearchBar.Text;
            BindingList<Item> source = ItemsGrid.DataSource as BindingList<Item>;
            items = source.Where(item => item.Name.StartsWith(query)).ToList();
        }


        private void ItemSearchBar_TextChanged(object sender, EventArgs e)
        {
            if (ItemSearchBar.Text == "")
            {
                items = Seller.Items;
            }
            else
            {
                SearchItem();
            }
            DataBind();
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ViewBtn_Click(object sender, EventArgs e)
        {
            int itemIndex = GetSelectedRow();
            if (itemIndex == -1) return;
            Item item = items[itemIndex];
            SellerForm sellerForm = this.Tag as SellerForm;
            ItemDetailsForm itemDetailsForm = new ItemDetailsForm();
            sellerForm.OpenChildForm(itemDetailsForm, item);
        }

        private int GetSelectedRow()
        {
            int index;
            if (ItemsGrid.SelectedCells.Count > 0)
            {
                index = ItemsGrid.SelectedCells[0].RowIndex;
            }
            else
            {
                index = -1;
            }
            return index;
        }

        private void ViewItemsForm_Load(object sender, EventArgs e)
        {
            Seller = ((SellerForm)Tag).SessionSeller;
            items = Seller.Items;
            DataBind();
        }

        private void ItemsGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
