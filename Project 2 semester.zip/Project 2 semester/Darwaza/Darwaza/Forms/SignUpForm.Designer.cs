﻿namespace Inventory.Forms.LoginPage
{
    partial class SignUpForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.BuyerPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.BuyerRadioBtn = new Guna.UI2.WinForms.Guna2RadioButton();
            this.SellerPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.SellerRadioBtn = new Guna.UI2.WinForms.Guna2RadioButton();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.PasswordLabel = new Guna.UI2.WinForms.Guna2TextBox();
            this.iconPictureBox4 = new FontAwesome.Sharp.IconPictureBox();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.FullNameLabel = new Guna.UI2.WinForms.Guna2TextBox();
            this.iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            this.UserNameLabel = new Guna.UI2.WinForms.Guna2TextBox();
            this.SignUpBtn = new Guna.UI2.WinForms.Guna2Button();
            this.LoginBtn = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel1.SuspendLayout();
            this.BuyerPanel.SuspendLayout();
            this.SellerPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Comic Sans MS", 26F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(219, 22);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(325, 62);
            this.guna2HtmlLabel1.TabIndex = 8;
            this.guna2HtmlLabel1.Text = "Create Account";
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2Panel1.Controls.Add(this.BuyerPanel);
            this.guna2Panel1.Controls.Add(this.SellerPanel);
            this.guna2Panel1.Controls.Add(this.guna2HtmlLabel4);
            this.guna2Panel1.Controls.Add(this.PasswordLabel);
            this.guna2Panel1.Controls.Add(this.iconPictureBox4);
            this.guna2Panel1.Controls.Add(this.guna2HtmlLabel2);
            this.guna2Panel1.Controls.Add(this.guna2HtmlLabel3);
            this.guna2Panel1.Controls.Add(this.FullNameLabel);
            this.guna2Panel1.Controls.Add(this.iconPictureBox2);
            this.guna2Panel1.Controls.Add(this.iconPictureBox1);
            this.guna2Panel1.Controls.Add(this.UserNameLabel);
            this.guna2Panel1.Controls.Add(this.SignUpBtn);
            this.guna2Panel1.Controls.Add(this.LoginBtn);
            this.guna2Panel1.Location = new System.Drawing.Point(110, 113);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(480, 558);
            this.guna2Panel1.TabIndex = 13;
            // 
            // BuyerPanel
            // 
            this.BuyerPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BuyerPanel.BorderColor = System.Drawing.Color.LightGray;
            this.BuyerPanel.BorderThickness = 1;
            this.BuyerPanel.Controls.Add(this.BuyerRadioBtn);
            this.BuyerPanel.CustomBorderColor = System.Drawing.Color.White;
            this.BuyerPanel.Location = new System.Drawing.Point(260, 34);
            this.BuyerPanel.Name = "BuyerPanel";
            this.BuyerPanel.Padding = new System.Windows.Forms.Padding(1);
            this.BuyerPanel.Size = new System.Drawing.Size(202, 43);
            this.BuyerPanel.TabIndex = 30;
            // 
            // BuyerRadioBtn
            // 
            this.BuyerRadioBtn.AutoSize = true;
            this.BuyerRadioBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BuyerRadioBtn.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BuyerRadioBtn.CheckedState.BorderThickness = 2;
            this.BuyerRadioBtn.CheckedState.FillColor = System.Drawing.Color.White;
            this.BuyerRadioBtn.CheckedState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BuyerRadioBtn.CheckedState.InnerOffset = -3;
            this.BuyerRadioBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BuyerRadioBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.BuyerRadioBtn.ForeColor = System.Drawing.Color.White;
            this.BuyerRadioBtn.Location = new System.Drawing.Point(52, 5);
            this.BuyerRadioBtn.Name = "BuyerRadioBtn";
            this.BuyerRadioBtn.Size = new System.Drawing.Size(122, 40);
            this.BuyerRadioBtn.TabIndex = 1;
            this.BuyerRadioBtn.Text = " Buyer";
            this.BuyerRadioBtn.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BuyerRadioBtn.UncheckedState.BorderThickness = 1;
            this.BuyerRadioBtn.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.BuyerRadioBtn.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.BuyerRadioBtn.UseVisualStyleBackColor = false;
            this.BuyerRadioBtn.CheckedChanged += new System.EventHandler(this.BuyerRadioBtn_CheckedChanged);
            // 
            // SellerPanel
            // 
            this.SellerPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.SellerPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SellerPanel.BorderThickness = 1;
            this.SellerPanel.Controls.Add(this.SellerRadioBtn);
            this.SellerPanel.CustomBorderColor = System.Drawing.Color.White;
            this.SellerPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SellerPanel.Location = new System.Drawing.Point(17, 34);
            this.SellerPanel.Name = "SellerPanel";
            this.SellerPanel.Padding = new System.Windows.Forms.Padding(1);
            this.SellerPanel.Size = new System.Drawing.Size(202, 43);
            this.SellerPanel.TabIndex = 29;
            // 
            // SellerRadioBtn
            // 
            this.SellerRadioBtn.AutoSize = true;
            this.SellerRadioBtn.Checked = true;
            this.SellerRadioBtn.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SellerRadioBtn.CheckedState.BorderThickness = 2;
            this.SellerRadioBtn.CheckedState.FillColor = System.Drawing.Color.White;
            this.SellerRadioBtn.CheckedState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SellerRadioBtn.CheckedState.InnerOffset = -3;
            this.SellerRadioBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SellerRadioBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.SellerRadioBtn.ForeColor = System.Drawing.Color.White;
            this.SellerRadioBtn.Location = new System.Drawing.Point(51, 5);
            this.SellerRadioBtn.Name = "SellerRadioBtn";
            this.SellerRadioBtn.Size = new System.Drawing.Size(120, 40);
            this.SellerRadioBtn.TabIndex = 0;
            this.SellerRadioBtn.TabStop = true;
            this.SellerRadioBtn.Text = " Seller";
            this.SellerRadioBtn.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SellerRadioBtn.UncheckedState.BorderThickness = 1;
            this.SellerRadioBtn.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.SellerRadioBtn.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.SellerRadioBtn.CheckedChanged += new System.EventHandler(this.SellerRadioBtn_CheckedChanged);
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel4.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(18, 303);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(168, 44);
            this.guna2HtmlLabel4.TabIndex = 27;
            this.guna2HtmlLabel4.Text = "Password";
            // 
            // PasswordLabel
            // 
            this.PasswordLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PasswordLabel.BorderThickness = 0;
            this.PasswordLabel.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PasswordLabel.DefaultText = "";
            this.PasswordLabel.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.PasswordLabel.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.PasswordLabel.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.PasswordLabel.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.PasswordLabel.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.PasswordLabel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.PasswordLabel.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.PasswordLabel.Location = new System.Drawing.Point(66, 344);
            this.PasswordLabel.Margin = new System.Windows.Forms.Padding(4);
            this.PasswordLabel.Name = "PasswordLabel";
            this.PasswordLabel.PasswordChar = '\0';
            this.PasswordLabel.PlaceholderText = "";
            this.PasswordLabel.SelectedText = "";
            this.PasswordLabel.Size = new System.Drawing.Size(397, 48);
            this.PasswordLabel.TabIndex = 28;
            // 
            // iconPictureBox4
            // 
            this.iconPictureBox4.BackColor = System.Drawing.Color.White;
            this.iconPictureBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.iconPictureBox4.IconChar = FontAwesome.Sharp.IconChar.Lock;
            this.iconPictureBox4.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.iconPictureBox4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox4.IconSize = 48;
            this.iconPictureBox4.Location = new System.Drawing.Point(18, 344);
            this.iconPictureBox4.Name = "iconPictureBox4";
            this.iconPictureBox4.Size = new System.Drawing.Size(48, 48);
            this.iconPictureBox4.TabIndex = 25;
            this.iconPictureBox4.TabStop = false;
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(18, 98);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(172, 44);
            this.guna2HtmlLabel2.TabIndex = 21;
            this.guna2HtmlLabel2.Text = "Full Name";
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(18, 199);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(191, 44);
            this.guna2HtmlLabel3.TabIndex = 23;
            this.guna2HtmlLabel3.Text = "User Name";
            // 
            // FullNameLabel
            // 
            this.FullNameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.FullNameLabel.BorderThickness = 0;
            this.FullNameLabel.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.FullNameLabel.DefaultText = "";
            this.FullNameLabel.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.FullNameLabel.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.FullNameLabel.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.FullNameLabel.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.FullNameLabel.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.FullNameLabel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.FullNameLabel.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.FullNameLabel.Location = new System.Drawing.Point(66, 139);
            this.FullNameLabel.Margin = new System.Windows.Forms.Padding(4);
            this.FullNameLabel.Name = "FullNameLabel";
            this.FullNameLabel.PasswordChar = '\0';
            this.FullNameLabel.PlaceholderText = "";
            this.FullNameLabel.SelectedText = "";
            this.FullNameLabel.Size = new System.Drawing.Size(397, 48);
            this.FullNameLabel.TabIndex = 22;
            // 
            // iconPictureBox2
            // 
            this.iconPictureBox2.BackColor = System.Drawing.Color.White;
            this.iconPictureBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.UserAlt;
            this.iconPictureBox2.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox2.IconSize = 48;
            this.iconPictureBox2.Location = new System.Drawing.Point(19, 240);
            this.iconPictureBox2.Name = "iconPictureBox2";
            this.iconPictureBox2.Size = new System.Drawing.Size(48, 48);
            this.iconPictureBox2.TabIndex = 20;
            this.iconPictureBox2.TabStop = false;
            // 
            // iconPictureBox1
            // 
            this.iconPictureBox1.BackColor = System.Drawing.Color.White;
            this.iconPictureBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.CircleUser;
            this.iconPictureBox1.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox1.IconSize = 48;
            this.iconPictureBox1.Location = new System.Drawing.Point(18, 139);
            this.iconPictureBox1.Name = "iconPictureBox1";
            this.iconPictureBox1.Size = new System.Drawing.Size(48, 48);
            this.iconPictureBox1.TabIndex = 19;
            this.iconPictureBox1.TabStop = false;
            // 
            // UserNameLabel
            // 
            this.UserNameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UserNameLabel.BorderThickness = 0;
            this.UserNameLabel.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.UserNameLabel.DefaultText = "";
            this.UserNameLabel.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.UserNameLabel.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.UserNameLabel.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.UserNameLabel.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.UserNameLabel.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.UserNameLabel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.UserNameLabel.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.UserNameLabel.Location = new System.Drawing.Point(66, 240);
            this.UserNameLabel.Margin = new System.Windows.Forms.Padding(4);
            this.UserNameLabel.Name = "UserNameLabel";
            this.UserNameLabel.PasswordChar = '\0';
            this.UserNameLabel.PlaceholderText = "";
            this.UserNameLabel.SelectedText = "";
            this.UserNameLabel.Size = new System.Drawing.Size(397, 48);
            this.UserNameLabel.TabIndex = 24;
            // 
            // SignUpBtn
            // 
            this.SignUpBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SignUpBtn.AutoRoundedCorners = true;
            this.SignUpBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.SignUpBtn.BorderRadius = 22;
            this.SignUpBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SignUpBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.SignUpBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.SignUpBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.SignUpBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.SignUpBtn.FillColor = System.Drawing.Color.Black;
            this.SignUpBtn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.SignUpBtn.ForeColor = System.Drawing.Color.White;
            this.SignUpBtn.Location = new System.Drawing.Point(17, 429);
            this.SignUpBtn.Name = "SignUpBtn";
            this.SignUpBtn.Size = new System.Drawing.Size(444, 46);
            this.SignUpBtn.TabIndex = 5;
            this.SignUpBtn.Text = "Sign Up";
            this.SignUpBtn.Click += new System.EventHandler(this.SignUpBtn_Click);
            // 
            // LoginBtn
            // 
            this.LoginBtn.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.LoginBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LoginBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.LoginBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.LoginBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.LoginBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.LoginBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.LoginBtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.LoginBtn.ForeColor = System.Drawing.Color.White;
            this.LoginBtn.Location = new System.Drawing.Point(17, 500);
            this.LoginBtn.Name = "LoginBtn";
            this.LoginBtn.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.LoginBtn.Size = new System.Drawing.Size(444, 33);
            this.LoginBtn.TabIndex = 6;
            this.LoginBtn.Text = "ALREADY HAVE AN ACCOUNT";
            this.LoginBtn.Click += new System.EventHandler(this.LoginBtn_Click);
            // 
            // SignUpForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(700, 692);
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Controls.Add(this.guna2Panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "SignUpForm";
            this.Text = "SignUpForm";
            this.Load += new System.EventHandler(this.SignUpForm_Load);
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            this.BuyerPanel.ResumeLayout(false);
            this.BuyerPanel.PerformLayout();
            this.SellerPanel.ResumeLayout(false);
            this.SellerPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2TextBox PasswordLabel;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2TextBox FullNameLabel;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private Guna.UI2.WinForms.Guna2TextBox UserNameLabel;
        private Guna.UI2.WinForms.Guna2Button SignUpBtn;
        private Guna.UI2.WinForms.Guna2Button LoginBtn;
        private Guna.UI2.WinForms.Guna2Panel BuyerPanel;
        private Guna.UI2.WinForms.Guna2RadioButton BuyerRadioBtn;
        private Guna.UI2.WinForms.Guna2Panel SellerPanel;
        private Guna.UI2.WinForms.Guna2RadioButton SellerRadioBtn;
    }
}