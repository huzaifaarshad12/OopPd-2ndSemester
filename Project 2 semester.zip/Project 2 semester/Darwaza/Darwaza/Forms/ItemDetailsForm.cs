﻿using Dll.BL;
using Dll.DL;
using Inventory.Forms.Seller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory.Forms
{
    public partial class ItemDetailsForm : Form
    {
        public ItemDetailsForm()
        {
            InitializeComponent();
        }

        private void PopulateLabels()
        {
            Item item = this.Tag.GetType().GetProperty("Payload").GetValue(this.Tag) as Item;
            NameLabel.Text = item.Name;
            DescriptionLabel.Text = item.Description;
            PriceLabel.Text = item.Price.ToString();
            QuantityLabel.Text = item.Quantity.ToString();
            SoldLabel.Text = item.Sold.ToString();
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            SellerForm form = this.Tag.GetType().GetProperty("Parent").GetValue(this.Tag) as SellerForm;
            form.OpenChildForm(new ViewItemsForm());
        }

        private void ItemDetailsForm_Load(object sender, EventArgs e)
        {
            PopulateLabels();
        }

        private void RemoveButton_Click(object sender, EventArgs e)
        {
            SellerForm form = this.Tag.GetType().GetProperty("Parent").GetValue(this.Tag) as SellerForm;
            Item item = this.Tag.GetType().GetProperty("Payload").GetValue(this.Tag) as Item;
            List<Item> items = form.SessionSeller.Items;
            DialogResult dialogResult = MessageBox.Show("Do You Want to Delete Selected Item?", "Delete Item", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                items.Remove(item);
                UserCRUD.RewriteUsers();
                form.OpenChildForm(new ViewItemsForm());
            }
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            SellerForm form = this.Tag.GetType().GetProperty("Parent").GetValue(this.Tag) as SellerForm;
            Item item = this.Tag.GetType().GetProperty("Payload").GetValue(this.Tag) as Item;
            form.OpenChildForm(new UpdateItemDetailsForm(), item, new ItemDetailsForm());
        }
    }
}
