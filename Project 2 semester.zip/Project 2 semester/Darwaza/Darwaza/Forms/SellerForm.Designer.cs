﻿namespace Inventory.Forms
{
    partial class SellerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.sideBar = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.LogOutButton = new FontAwesome.Sharp.IconButton();
            this.ViewStats = new FontAwesome.Sharp.IconButton();
            this.RemoveItemBtn = new FontAwesome.Sharp.IconButton();
            this.UpdateItemBtn = new FontAwesome.Sharp.IconButton();
            this.ViewItemsBtn = new FontAwesome.Sharp.IconButton();
            this.AddItemBtn = new FontAwesome.Sharp.IconButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.sellerChangeAble = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.sideBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).BeginInit();
            this.sellerChangeAble.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.sideBar, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1200, 692);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // sideBar
            // 
            this.sideBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(107)))), ((int)(((byte)(147)))));
            this.sideBar.Controls.Add(this.pictureBox3);
            this.sideBar.Controls.Add(this.LogOutButton);
            this.sideBar.Controls.Add(this.ViewStats);
            this.sideBar.Controls.Add(this.RemoveItemBtn);
            this.sideBar.Controls.Add(this.UpdateItemBtn);
            this.sideBar.Controls.Add(this.ViewItemsBtn);
            this.sideBar.Controls.Add(this.AddItemBtn);
            this.sideBar.Controls.Add(this.pictureBox1);
            this.sideBar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sideBar.Location = new System.Drawing.Point(0, 0);
            this.sideBar.Margin = new System.Windows.Forms.Padding(0);
            this.sideBar.Name = "sideBar";
            this.sideBar.Size = new System.Drawing.Size(250, 692);
            this.sideBar.TabIndex = 1;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox3.Image = global::Inventory.Properties.Resources._360_F_541022338_YBWUEqRTPExosIPtHH7b8ZHQuclW4unG;
            this.pictureBox3.Location = new System.Drawing.Point(0, 409);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(250, 202);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // LogOutButton
            // 
            this.LogOutButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.LogOutButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LogOutButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.LogOutButton.FlatAppearance.BorderSize = 0;
            this.LogOutButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LogOutButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogOutButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.LogOutButton.IconChar = FontAwesome.Sharp.IconChar.PowerOff;
            this.LogOutButton.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.LogOutButton.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.LogOutButton.IconSize = 28;
            this.LogOutButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LogOutButton.Location = new System.Drawing.Point(0, 602);
            this.LogOutButton.Name = "LogOutButton";
            this.LogOutButton.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.LogOutButton.Size = new System.Drawing.Size(250, 90);
            this.LogOutButton.TabIndex = 6;
            this.LogOutButton.Text = "       Log Out";
            this.LogOutButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LogOutButton.UseVisualStyleBackColor = false;
            this.LogOutButton.Click += new System.EventHandler(this.LogOutButton_Click);
            // 
            // ViewStats
            // 
            this.ViewStats.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.ViewStats.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ViewStats.Dock = System.Windows.Forms.DockStyle.Top;
            this.ViewStats.FlatAppearance.BorderSize = 0;
            this.ViewStats.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ViewStats.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewStats.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.ViewStats.IconChar = FontAwesome.Sharp.IconChar.ChartSimple;
            this.ViewStats.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.ViewStats.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ViewStats.IconSize = 28;
            this.ViewStats.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ViewStats.Location = new System.Drawing.Point(0, 356);
            this.ViewStats.Name = "ViewStats";
            this.ViewStats.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.ViewStats.Size = new System.Drawing.Size(250, 53);
            this.ViewStats.TabIndex = 5;
            this.ViewStats.Text = "       View Stats";
            this.ViewStats.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ViewStats.UseVisualStyleBackColor = false;
            // 
            // RemoveItemBtn
            // 
            this.RemoveItemBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.RemoveItemBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RemoveItemBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.RemoveItemBtn.FlatAppearance.BorderSize = 0;
            this.RemoveItemBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RemoveItemBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RemoveItemBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.RemoveItemBtn.IconChar = FontAwesome.Sharp.IconChar.Trash;
            this.RemoveItemBtn.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.RemoveItemBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.RemoveItemBtn.IconSize = 28;
            this.RemoveItemBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RemoveItemBtn.Location = new System.Drawing.Point(0, 316);
            this.RemoveItemBtn.Name = "RemoveItemBtn";
            this.RemoveItemBtn.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.RemoveItemBtn.Size = new System.Drawing.Size(250, 40);
            this.RemoveItemBtn.TabIndex = 4;
            this.RemoveItemBtn.Text = "       Remove Item";
            this.RemoveItemBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RemoveItemBtn.UseVisualStyleBackColor = false;
            this.RemoveItemBtn.Click += new System.EventHandler(this.RemoveItemBtn_Click);
            // 
            // UpdateItemBtn
            // 
            this.UpdateItemBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.UpdateItemBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UpdateItemBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.UpdateItemBtn.FlatAppearance.BorderSize = 0;
            this.UpdateItemBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UpdateItemBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateItemBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.UpdateItemBtn.IconChar = FontAwesome.Sharp.IconChar.Wrench;
            this.UpdateItemBtn.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.UpdateItemBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.UpdateItemBtn.IconSize = 28;
            this.UpdateItemBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.UpdateItemBtn.Location = new System.Drawing.Point(0, 276);
            this.UpdateItemBtn.Name = "UpdateItemBtn";
            this.UpdateItemBtn.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.UpdateItemBtn.Size = new System.Drawing.Size(250, 40);
            this.UpdateItemBtn.TabIndex = 3;
            this.UpdateItemBtn.Text = "       Update Item";
            this.UpdateItemBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.UpdateItemBtn.UseVisualStyleBackColor = false;
            this.UpdateItemBtn.Click += new System.EventHandler(this.UpdateItemBtn_Click);
            // 
            // ViewItemsBtn
            // 
            this.ViewItemsBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.ViewItemsBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ViewItemsBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.ViewItemsBtn.FlatAppearance.BorderSize = 0;
            this.ViewItemsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ViewItemsBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewItemsBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.ViewItemsBtn.IconChar = FontAwesome.Sharp.IconChar.ListUl;
            this.ViewItemsBtn.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.ViewItemsBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ViewItemsBtn.IconSize = 28;
            this.ViewItemsBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ViewItemsBtn.Location = new System.Drawing.Point(0, 236);
            this.ViewItemsBtn.Name = "ViewItemsBtn";
            this.ViewItemsBtn.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.ViewItemsBtn.Size = new System.Drawing.Size(250, 40);
            this.ViewItemsBtn.TabIndex = 2;
            this.ViewItemsBtn.Text = "       View Items";
            this.ViewItemsBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ViewItemsBtn.UseVisualStyleBackColor = false;
            this.ViewItemsBtn.Click += new System.EventHandler(this.ViewItemsBtn_Click);
            // 
            // AddItemBtn
            // 
            this.AddItemBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.AddItemBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddItemBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.AddItemBtn.FlatAppearance.BorderSize = 0;
            this.AddItemBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddItemBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddItemBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.AddItemBtn.IconChar = FontAwesome.Sharp.IconChar.BasketShopping;
            this.AddItemBtn.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(255)))), ((int)(((byte)(134)))));
            this.AddItemBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.AddItemBtn.IconSize = 28;
            this.AddItemBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AddItemBtn.Location = new System.Drawing.Point(0, 196);
            this.AddItemBtn.Name = "AddItemBtn";
            this.AddItemBtn.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.AddItemBtn.Size = new System.Drawing.Size(250, 40);
            this.AddItemBtn.TabIndex = 1;
            this.AddItemBtn.Text = "       Add Item";
            this.AddItemBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AddItemBtn.UseVisualStyleBackColor = false;
            this.AddItemBtn.Click += new System.EventHandler(this.AddItemBtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Image = global::Inventory.Properties.Resources._360_F_541022338_YBWUEqRTPExosIPtHH7b8ZHQuclW4unG;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(250, 196);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.sellerChangeAble, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(250, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(950, 692);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.iconPictureBox1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 632);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(950, 60);
            this.panel1.TabIndex = 0;
            // 
            // iconPictureBox1
            // 
            this.iconPictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.iconPictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Dungeon;
            this.iconPictureBox1.IconColor = System.Drawing.Color.White;
            this.iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox1.IconSize = 60;
            this.iconPictureBox1.Location = new System.Drawing.Point(354, -3);
            this.iconPictureBox1.Name = "iconPictureBox1";
            this.iconPictureBox1.Size = new System.Drawing.Size(60, 60);
            this.iconPictureBox1.TabIndex = 1;
            this.iconPictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(426, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(213, 29);
            this.label2.TabIndex = 2;
            this.label2.Text = "Shopping Made Easy";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(420, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 48);
            this.label1.TabIndex = 1;
            this.label1.Text = "Inventory";
            // 
            // sellerChangeAble
            // 
            this.sellerChangeAble.Controls.Add(this.pictureBox2);
            this.sellerChangeAble.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sellerChangeAble.Location = new System.Drawing.Point(0, 0);
            this.sellerChangeAble.Margin = new System.Windows.Forms.Padding(0);
            this.sellerChangeAble.Name = "sellerChangeAble";
            this.sellerChangeAble.Size = new System.Drawing.Size(950, 632);
            this.sellerChangeAble.TabIndex = 1;
            this.sellerChangeAble.Paint += new System.Windows.Forms.PaintEventHandler(this.sellerChangeAble_Paint);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Default;
            this.pictureBox2.Image = global::Inventory.Properties.Resources._360_F_542850615_1B16r8qsUa5oR8zq4td8wqi911uczewS;
            this.pictureBox2.Location = new System.Drawing.Point(227, 59);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(500, 494);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // SellerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(75)))), ((int)(((byte)(96)))));
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "SellerForm";
            this.Text = "Seller Menu";
            this.Load += new System.EventHandler(this.SellerForm_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.sideBar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).EndInit();
            this.sellerChangeAble.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel sideBar;
        private FontAwesome.Sharp.IconButton LogOutButton;
        private FontAwesome.Sharp.IconButton ViewStats;
        private FontAwesome.Sharp.IconButton RemoveItemBtn;
        private FontAwesome.Sharp.IconButton UpdateItemBtn;
        private FontAwesome.Sharp.IconButton ViewItemsBtn;
        private FontAwesome.Sharp.IconButton AddItemBtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel sellerChangeAble;
        private System.Windows.Forms.PictureBox pictureBox2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}