﻿using Dll.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory.Forms
{
    public partial class BuyerForm : Form
    {
        public Form activeForm = null;
        public BuyerUser SessionBuyer;
        public BuyerForm()
        {
            InitializeComponent();
        }
        public void OpenChildForm(Form childForm)
        {
            activeForm?.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            buyerChangeAble.Controls.Add(childForm);
            buyerChangeAble.Tag = childForm;
            childForm.Tag = this;
            childForm.BringToFront();
            childForm.Show();
        }

        public void OpenChildForm(Form childForm, object tagValue)
        {
            activeForm?.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            buyerChangeAble.Controls.Add(childForm);
            buyerChangeAble.Tag = childForm;
            childForm.Tag = new { Parent = this, Payload = tagValue };
            childForm.BringToFront();
            childForm.Show();
        }

        public void OpenChildForm(Form childForm, object tagValue, Form openingForm)
        {
            activeForm?.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            buyerChangeAble.Controls.Add(childForm);
            buyerChangeAble.Tag = childForm;
            childForm.Tag = new { Parent = this, Child = openingForm, Payload = tagValue };
            childForm.BringToFront();
            childForm.Show();
        }

        private void BuyerForm_Load(object sender, EventArgs e)
        {
            SessionBuyer = ((MainForm)this.Tag).SessionUser as BuyerUser;
        }

        private void VisitMarketPlaceBtn_Click(object sender, EventArgs e)
        {
            OpenChildForm(new VisitMarketPlaceForm());
        }

        private void LogOutButton_Click(object sender, EventArgs e)
        {
            MainForm form = this.Tag as MainForm;
            form.OpenChildForm(new LoginPageForm());
        }

        private void ViewCartBtn_Click(object sender, EventArgs e)
        {
            OpenChildForm(new ViewCartForm());
        }

        private void TrackOrderBtn_Click(object sender, EventArgs e)
        {
            OpenChildForm(new ViewOrderForm());
        }

        private void NotificationsBtn_Click(object sender, EventArgs e)
        {
            OpenChildForm(new ViewNotificationsForm());
        }

        private void buyerChangeAble_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2CustomGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void sideBar_Paint(object sender, PaintEventArgs e)
        {

        }

        private void iconButton1_Click(object sender, EventArgs e)
        {

        }
    }
}
