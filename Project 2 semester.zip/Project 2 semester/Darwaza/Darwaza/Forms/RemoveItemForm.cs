﻿using Dll.BL;
using Dll.DL;
using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory.Forms
{
    public partial class RemoveItemForm : Form
    {
        private SellerUser Seller;
        private List<Item> items;
        public RemoveItemForm()
        {
            InitializeComponent();
        }

        private void DataBind()
        {
            ItemsGrid.DataSource = new BindingList<Item>(items);
        }

        private void SearchItem()
        {
            string query = ItemSearchBar.Text;
            BindingList<Item> source = ItemsGrid.DataSource as BindingList<Item>;
            items = source.Where(item => item.Name.StartsWith(query)).ToList();
        }

        private void ItemSearchBar_TextChanged(object sender, EventArgs e)
        {
            if (ItemSearchBar.Text == "")
            {
                items = Seller.Items;
            }
            else
            {
                SearchItem();
            }
            DataBind();
        }

        private void RemoveBtn_Click(object sender, EventArgs e)
        {
            int row = GetSelectedRow();
            if (row == -1) return;
            DialogResult dialogResult = MessageBox.Show("Do You Want to Delete Selected Item?", "Delete Item", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Item item = items[row];
                items = Seller.Items;
                items.Remove(item);
                UserCRUD.RewriteUsers();
                DataBind();
                ItemSearchBar.Clear();
            }
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private int GetSelectedRow()
        {
            int index;
            if (ItemsGrid.SelectedCells.Count > 0)
            {
                index = ItemsGrid.SelectedCells[0].RowIndex;
            }
            else
            {
                index = -1;
            }
            return index;
        }

        private void RemoveItemForm_Load(object sender, EventArgs e)
        {
            Seller = ((SellerForm)Tag).SessionSeller;
            items = Seller.Items;
            DataBind();
        }
    }
}
