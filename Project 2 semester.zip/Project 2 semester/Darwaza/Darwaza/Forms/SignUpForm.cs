﻿using Dll.BL;
using Dll.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory.Forms.LoginPage
{
    public partial class SignUpForm : Form
    {
        public SignUpForm()
        {
            InitializeComponent();
        }

        private void SellerRadioBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (SellerRadioBtn.Checked)
            {
                BuyerRadioBtn.Checked = false;
                BuyerPanel.BorderColor = Color.LightGray;
                SellerPanel.BorderColor = Color.FromArgb(94, 148, 225);
            }
        }

        private void BuyerRadioBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (BuyerRadioBtn.Checked)
            {
                SellerRadioBtn.Checked = false;
                SellerPanel.BorderColor = Color.LightGray;
                BuyerPanel.BorderColor = Color.FromArgb(94, 148, 225);
            }
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            LoginPageForm form = this.Tag as LoginPageForm;
            form.OpenChildForm(new SignInForm());
        }

        private void SignUpBtn_Click(object sender, EventArgs e)
        {
            User user;
            string userName = UserNameLabel.Text;
            string fullName = FullNameLabel.Text;
            string password = PasswordLabel.Text;
            if (SellerRadioBtn.Checked)
            {
                user = new SellerUser(fullName, userName, password);
            }
            else
            {
                user = new BuyerUser(fullName, userName, password);
            }
            UserCRUD.AddUser(user);
            UserCRUD.RewriteUsers();
            MessageBox.Show("Account Created Successfully");
            LoginPageForm form = this.Tag as LoginPageForm;
            form.OpenChildForm(new SignInForm());
        }

        private void SignUpForm_Load(object sender, EventArgs e)
        {

        }
    }
}
