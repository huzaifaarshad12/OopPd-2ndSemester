﻿using Dll.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory.Forms
{
    public partial class SellerForm : Form
    {
        public Form activeForm = null;
        public SellerUser SessionSeller;
        public SellerForm()
        {
            InitializeComponent();
        }

        public void OpenChildForm(Form childForm)
        {
            activeForm?.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            sellerChangeAble.Controls.Add(childForm);
            sellerChangeAble.Tag = childForm;
            childForm.Tag = this;
            childForm.BringToFront();
            childForm.Show();
        }

        public void OpenChildForm(Form childForm, object tagValue)
        {
            activeForm?.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            sellerChangeAble.Controls.Add(childForm);
            sellerChangeAble.Tag = childForm;
            childForm.Tag = new { Parent = this, Payload = tagValue };
            childForm.BringToFront();
            childForm.Show();
        }

        public void OpenChildForm(Form childForm, object tagValue, Form openingForm)
        {
            activeForm?.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            sellerChangeAble.Controls.Add(childForm);
            sellerChangeAble.Tag = childForm;
            childForm.Tag = new { Parent = this, Child = openingForm, Payload = tagValue };
            childForm.BringToFront();
            childForm.Show();
        }
        private void AddItemBtn_Click(object sender, EventArgs e)
        {
            OpenChildForm(new AddItemForm());
        }

        private void ViewItemsBtn_Click(object sender, EventArgs e)
        {
            ViewItemsForm viewItemsForm = new ViewItemsForm();
            viewItemsForm.Tag = this;
            OpenChildForm(viewItemsForm);
        }

        private void UpdateItemBtn_Click(object sender, EventArgs e)
        {
            OpenChildForm(new UpdateItemForm());
        }

        private void RemoveItemBtn_Click(object sender, EventArgs e)
        {
            OpenChildForm(new RemoveItemForm());
        }

        private void LogOutButton_Click(object sender, EventArgs e)
        {
            MainForm form = this.Tag as MainForm;
            form.OpenChildForm(new LoginPageForm());
        }

        private void SellerForm_Load(object sender, EventArgs e)
        {
            SessionSeller = ((MainForm)this.Tag).SessionUser as SellerUser;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void sellerChangeAble_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }
    }
}
