﻿using Dll.BL;
using Dll.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory.Forms
{
    public partial class ViewOrderForm : Form
    {
        private List<CheckOut> checkOuts;
        private BuyerUser Buyer;
        public ViewOrderForm()
        {
            InitializeComponent();
        }
        private void DataBind()
        {
            ItemsGrid.DataSource = new BindingList<CheckOut>(checkOuts);
        }

        private void SearchItem()
        {
            string query = ItemSearchBar.Text;
            BindingList<CheckOut> source = ItemsGrid.DataSource as BindingList<CheckOut>;
            checkOuts = source.Where(order => order.ItemName.StartsWith(query)).ToList();
        }


        private void ItemSearchBar_TextChanged(object sender, EventArgs e)
        {
            if (ItemSearchBar.Text == "")
            {
                checkOuts = Buyer.CheckOuts;
            }
            else
            {
                SearchItem();
            }
            DataBind();
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ViewOrderForm_Load(object sender, EventArgs e)
        {
            BuyerForm form = this.Tag as BuyerForm;
            Buyer = form.SessionBuyer;
            checkOuts = Buyer.CheckOuts;
            DataBind();
        }
    }
}
