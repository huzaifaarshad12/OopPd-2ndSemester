﻿using Dll.BL;
using Dll.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory.Forms
{
    public partial class ViewCartForm : Form
    {
        private List<Order> orders;
        private BuyerUser Buyer;
        public ViewCartForm()
        {
            InitializeComponent();
        }
        private void DataBind()
        {
            ItemsGrid.DataSource = new BindingList<Order>(orders);
        }

        private void SearchItem()
        {
            string query = ItemSearchBar.Text;
            BindingList<Order> source = ItemsGrid.DataSource as BindingList<Order>;
            orders = source.Where(order => order.ItemName.StartsWith(query)).ToList();
        }


        private void ItemSearchBar_TextChanged(object sender, EventArgs e)
        {
            if (ItemSearchBar.Text == "")
            {
                orders = Buyer.Cart.Orders;
            }
            else
            {
                SearchItem();
            }
            DataBind();
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void ViewCartForm_Load(object sender, EventArgs e)
        {
            BuyerForm form = this.Tag as BuyerForm;
            Buyer = form.SessionBuyer;
            orders = Buyer.Cart.Orders;
            DataBind();
        }

        private void CheckOutBtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Do You Want to Check Out All Items?", "Check Out All Items", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Buyer.CheckOutAll();
                orders = Buyer.Cart.Orders;
                DataBind();
            }
        }
    }
}
