﻿using InventoryConsole.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dll.BL;
using Dll.DL;

namespace InventoryConsole.Controller
{
    public class MainController
    {
        public static User Start()
        {
            do
            {
                int option = MainUI.Menu();
                if (option == 0)
                {
                    User user = MainUI.Login();
                    if (user != null) return user;
                }
                else if (option == 1)
                {
                    User user = MainUI.SignUp();
                    UserCRUD.AddUser(user);
                    UserCRUD.RewriteUsers();
                }
                else if (option == 2)
                {
                    MainUI.PrintManual();
                }
                else
                {
                    Environment.Exit(0);
                }
            }
            while (true);
        }
    }
}
