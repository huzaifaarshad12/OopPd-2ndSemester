﻿using Dll.BL;
using Dll.DL;
using InventoryConsole.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace InventoryConsole.Controller
{
    class BuyerController
    {
        public static void Start(Buyer buyer)
        {
            int option;
            List<Item> items = UserCRUD.Users
                .Where(user => user is Seller)
                .Aggregate(new List<Item>(), (acc, user) => acc.Concat(((Seller)user).Items).ToList());
            do
            {
                option = BuyerUI.Menu();
                if (option == 0)
                {
                    do
                    {
                        Window.PrintComponent("Buyer > Market Place");
                        int itemIndex = ItemUI.ViewItems(items);
                        if (itemIndex == -1) break;
                        HandleItemDisplay(buyer, items[itemIndex], "Buyer > Market Place");
                    } while (true);
                }
                else if (option == 1)
                {
                    string itemName = BuyerUI.SearchItem();
                    List<Item> searchedItems = items.FindAll(item => item.Name.StartsWith(itemName));
                    int itemIndex = ItemUI.ViewItems(searchedItems);
                    if (itemIndex != -1)
                    {
                        
                        HandleItemDisplay(buyer, items[itemIndex], "Buyer > Search Item");
                    }
                }
                else if (option == 2)
                {
                    do
                    {
                        int cartIndex = BuyerUI.DisplayCart(buyer.Cart.Orders);
                        if (cartIndex == -1) break;
                        int miniOption = BuyerUI.DisplayCartItem(buyer.Cart.Orders[cartIndex]);
                        if (miniOption == 0)
                        {
                            buyer.CheckOutItem(cartIndex);
                            UserCRUD.RewriteUsers();
                        }
                        else if (miniOption == 1)
                        {
                            buyer.RemoveFromCart(cartIndex);
                            UserCRUD.RewriteUsers();
                        }
                    }
                    while (true);
                }
                else if (option == 3)
                {
                    int selection = BuyerUI.CheckOutAllItems();
                    if (selection == 0)
                    {
                        buyer.CheckOutAll();
                        UserCRUD.RewriteUsers();
                    }
                }
                else if (option == 4)
                {
                    do
                    {
                        int checkOutIndex = BuyerUI.DisplayCheckOuts(buyer.CheckOuts);
                        if (checkOutIndex == -1) break;
                        int miniOption = BuyerUI.DisplayCheckOutItem(buyer.CheckOuts[checkOutIndex]);
                        if (miniOption == 0)
                        {
                            buyer.CancelOrder(checkOutIndex);
                            UserCRUD.RewriteUsers();
                        }
                    } while (true);
                }
                else
                {
                    break;
                }
            } while (true);
        }

        public static void HandleItemDisplay(Buyer buyer, Item item, string title)
        {
            ItemUI.ShowItemDetails(item, title);
            int miniOption = BuyerUI.MiniMenu();
            if (miniOption == 0)
            {
                Order order = BuyerUI.AddToCart(item);
                buyer.AddOrder(order);
                order.Item.Purchase(order.Quantity);
                Window.PrintConfirmationDialog(new List<string> { string.Format("{0} Added to the Cart Successfully!!!", item.Name) });
                UserCRUD.RewriteUsers();
            }
            else if (miniOption == 1)
            {
                CheckOut checkOut = BuyerUI.PlaceOrder(item);
                buyer.AddCheckOut(checkOut);
                checkOut.Order.Item.Purchase(checkOut.Order.Quantity);
                Window.PrintConfirmationDialog(new List<string> { string.Format("{0} Order Placed Successfully!!!", item.Name) });
                UserCRUD.RewriteUsers();
            }
        }
    }
}
