﻿namespace InventoryConsole.Controller
{
    public class Buyer
    {
    }
}