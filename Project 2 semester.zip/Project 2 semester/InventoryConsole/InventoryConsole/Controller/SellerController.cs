﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dll.BL;
using InventoryConsole.UI;
using Dll.DL;

namespace InventoryConsole.Controller
{
    public class SellerController
    {
        public static void Start(Seller seller)
        {
            int option;
            do
            {
                option = SellerUI.Menu();
                if (option == 0)
                {
                    Item item = SellerUI.CreateItem(seller.FullName);
                    seller.AddItem(item);
                    UserCRUD.RewriteUsers();
                }
                else if (option == 1)
                {
                    do
                    {
                        Window.PrintComponent("Seller > View Items");
                        int itemNumber = ItemUI.ViewItems(seller.Items);
                        if (itemNumber == -1) break;
                        ItemUI.ShowItemDetails(seller.GetItem(itemNumber), "Seller > View Items", true);
                        int miniOption = SellerUI.MiniMenu();
                        if (miniOption == 0)
                        {
                            SellerUI.UpdateItem(seller.GetItem(itemNumber));
                            UserCRUD.RewriteUsers();
                        }
                        else if (miniOption == 1)
                        {
                            bool flag = SellerUI.RemoveItem(seller.GetItem(itemNumber));
                            if (flag)
                            {
                                seller.RemoveItem(itemNumber);
                                UserCRUD.RewriteUsers();
                            }
                        }
                    }
                    while (true);
                }
                else if (option == 2)
                {
                    do
                    {
                        Window.PrintComponent("Seller > Update Items");
                        int itemNumber = ItemUI.ViewItems(seller.Items);
                        if (itemNumber == -1) break;
                        SellerUI.UpdateItem(seller.GetItem(itemNumber));
                        UserCRUD.RewriteUsers();
                    }
                    while (true);
                }
                else if (option == 3)
                {
                    do
                    {
                        Window.PrintComponent("Seller > View Items");
                        int itemNumber = ItemUI.ViewItems(seller.Items);
                        if (itemNumber == -1) break;
                        bool flag = SellerUI.RemoveItem(seller.GetItem(itemNumber));
                        if (flag)
                        {
                            seller.RemoveItem(itemNumber);
                            UserCRUD.RewriteUsers();
                        }
                    }
                    while (true);
                }
                else if (option == 4)
                {
                    SellerUI.PrintStats(seller.Items);
                }
                else if (option == 5)
                {
                    break;
                }
            } while (true);
        }
    }
}
