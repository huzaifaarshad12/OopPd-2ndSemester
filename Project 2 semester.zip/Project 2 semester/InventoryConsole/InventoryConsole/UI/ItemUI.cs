﻿using Dll.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryConsole.UI
{
    class ItemUI : Window
    {
        public static int ViewItems(List<Item> sellerItems)
        {
            if (sellerItems == null || sellerItems.Count == 0)
            {
                PrintConfirmationDialog(new List<string> { "NO ITEMS FOUND" });
                return -1;
            }
            List<List<string>> items = new List<List<string>>();
            foreach (var item in sellerItems)
            {
                List<string> currentItem = new List<string>
                {
                    item.Name,
                    string.Format("PKR {0} - {1}", item.Price.ToString(), (item.Quantity > 0) ? "In-Stock" : "Out-Of-Stock"),
                    string.Format("Seller: {0}", item.Seller)
                };
                items.Add(currentItem);
            }
            Menu menu = new Menu(items, true);
            return menu.Initialize();
        }

        public static void ShowItemDetails(Item item, string title, bool isSeller = false)
        {
            PrintComponent(title + " > " + item.Name);
            Console.WriteLine("".PadRight(OptionPadding) + "Item Name: " + item.Name);
            Console.WriteLine("".PadRight(OptionPadding) + "Item Description: " + item.Description);
            Console.WriteLine("".PadRight(OptionPadding) + "Item Price: PKR " + item.Price);
            Console.WriteLine("".PadRight(OptionPadding) + "Item Remaining Quantity: " + item.Quantity);
            if (isSeller)
            {
                Console.WriteLine("".PadRight(OptionPadding) + "Item Sold: " + item.Sold);
            }
            Console.WriteLine();
        }
    }
}
