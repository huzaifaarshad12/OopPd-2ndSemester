﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryConsole.UI
{
    class Window
    {
        static private int _width;
        static private int _height;
        static private int _headerPadding;
        static private int _optionPadding;

        static public void Initialize()
        {
            _width = Console.LargestWindowWidth;
            _height = Console.LargestWindowHeight;
            Console.SetBufferSize(_width, _height);
            Console.SetWindowSize(_width, _height);
            Console.SetWindowPosition(0, 0);
            SetPaddings();
        }

        static private void SetPaddings()
        {
            int _headerWidth = 97;
            _headerPadding = (_width - _headerWidth) / 2;
            _optionPadding = (int)((float)15 / 100 * _width);
        }

        static private void PrintHeader()
        {
            Console.Write("\n\n\n");
            Console.WriteLine("".PadRight(_headerPadding) + "$$$$$$$\\   $$$$$$\\  $$$$$$$\\  $$\\      $$\\  $$$$$$\\  $$$$$$$$\\  $$$$$$\\      $$$$$$$\\  $$\\   $$\\ ");
            Console.WriteLine("".PadRight(_headerPadding) + "$$  __$$\\ $$  __$$\\ $$  __$$\\ $$ | $\\  $$ |$$  __$$\\ \\____$$  |$$  __$$\\     $$  __$$\\ $$ | $$  |");
            Console.WriteLine("".PadRight(_headerPadding) + "$$ |  $$ |$$ /  $$ |$$ |  $$ |$$ |$$$\\ $$ |$$ /  $$ |    $$  / $$ /  $$ |    $$ |  $$ |$$ |$$  / ");
            Console.WriteLine("".PadRight(_headerPadding) + "$$ |  $$ |$$$$$$$$ |$$$$$$$  |$$ $$ $$\\$$ |$$$$$$$$ |   $$  /  $$$$$$$$ |    $$$$$$$  |$$$$$  /  ");
            Console.WriteLine("".PadRight(_headerPadding) + "$$ |  $$ |$$  __$$ |$$  __$$< $$$$  _$$$$ |$$  __$$ |  $$  /   $$  __$$ |    $$  ____/ $$  $$<   ");
            Console.WriteLine("".PadRight(_headerPadding) + "$$ |  $$ |$$ |  $$ |$$ |  $$ |$$$  / \\$$$ |$$ |  $$ | $$  /    $$ |  $$ |    $$ |      $$ |\\$$\\  ");
            Console.WriteLine("".PadRight(_headerPadding) + "$$$$$$$  |$$ |  $$ |$$ |  $$ |$$  /   \\$$ |$$ |  $$ |$$$$$$$$\\ $$ |  $$ |$$\\ $$ |      $$ | \\$$\\ ");
            Console.WriteLine("".PadRight(_headerPadding) + "\\_______/ \\__|  \\__|\\__|  \\__|\\__/     \\__|\\__|  \\__|\\________|\\__|  \\__|\\__|\\__|      \\__|  \\__|");
            Console.Write("\n\n\n");
            //PrintLine();
            Console.WriteLine();
        }

        

        static public void PrintComponent(string title)
        {
            //Console.Clear();
            PrintHeader();
            Console.WriteLine("".PadRight(_optionPadding) + "DARWAZA.PK > " + title);
            Console.WriteLine();
        }

        static public void PrintConfirmationDialog(List<string> messages)
        {
            ConsoleKeyInfo key;
            Console.WriteLine();
            foreach (var message in messages)
            {
                Console.WriteLine("".PadRight(OptionPadding) + message);
            }
            Console.WriteLine();
            Console.Write("".PadRight(OptionPadding) + ">  OK");
            do
            {
                key = Console.ReadKey(true);
            } while (key.Key != ConsoleKey.Enter);
        }

        static public int PrintTryAgainDialog(List<string> messages)
        {
            Console.WriteLine();
            foreach (var message in messages)
            {
                Console.WriteLine("".PadRight(OptionPadding) + message);
            }
            Console.WriteLine();
            List<List<string>> options = new List<List<string>>
            {
                new List<string> { "Try Again" },
                new List<string> { "Continue" }
            };
            Menu menu = new Menu(options);
            return menu.Initialize();
        }
        static protected int Width
        {
            get => _width;
        }

        static protected int Height
        {
            get => _height;
        }

        static protected int OptionPadding
        {
            get => _optionPadding;
        }

    }
}
