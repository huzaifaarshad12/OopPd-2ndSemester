﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dll.BL;
using Dll.DL;

namespace InventoryConsole.UI
{
    class MainUI : Window
    {
        public static int Menu()
        {
            PrintComponent("Index");
            List<List<string>> options = new List<List<string>>
            {
                new List<string> { "Login to Your Account" },
                new List<string> { "Create Account & Sign Up" },
                new List<string> { "Read Application Manual" },
                new List<string> { "Exit" },
            };
            Menu menu = new Menu(options);
            return menu.Initialize();
        }

        public static User SignUp()
        {
            User user;
            PrintComponent("Sign Up");
            int y = Console.CursorTop;
            Console.WriteLine("".PadRight(OptionPadding) + "Select Account Type: ");
            List<List<string>> options = new List<List<string>>
            {
                new List<string> { "Seller" },
                new List<string> { "Buyer" }
            };
            Menu menu = new Menu(options);
            int type = menu.Initialize();
            Console.SetCursorPosition(0, y + 4);
            Console.Write("".PadRight(OptionPadding) + "Full Name: ");
            string fullName = Console.ReadLine();
            Console.Write("".PadRight(OptionPadding) + "Username: ");
            string userName = Console.ReadLine();
            Console.Write("".PadRight(OptionPadding) + "Password: ");
            string password = Console.ReadLine();
            if (type == 0)
            {
                user = new Seller(fullName, userName, password);
            }
            else
            {
                user = new Buyer(fullName, userName, password);
            }
            PrintConfirmationDialog(new List<string> { "Account Created Successfully!!!" });
            return user;
        }

        public static User Login()
        {
            User user;
            string userName;
            string password;
            do
            {
                PrintComponent("Login");
                Console.Write("".PadRight(OptionPadding) + "Username: ");
                userName = Console.ReadLine();
                Console.Write("".PadRight(OptionPadding) + "Password: ");
                password = Console.ReadLine();
                user = UserCRUD.FindUser(userName, password);
                if (user != null)
                {
                    PrintConfirmationDialog(new List<string> { "Login Successfully!!!" });
                    break;
                }
                else
                {
                    int option = PrintTryAgainDialog(new List<string> { "Login Failed!!!", "Incorrect Username/Password" });
                    if (option == 1) break;
                }
            }
            while (true);
            return user;
        }

        public static void PrintManual()
        {
            PrintComponent("Application Manual");
            Console.WriteLine("".PadRight(OptionPadding) + "Navigation System: \n");
            Console.WriteLine("".PadRight(OptionPadding) + "1. Up/Down Arrow Key - Move Between Options\n");
            Console.WriteLine("".PadRight(OptionPadding) + "2. Right/Left Arrow Key - Move Between Different Pages");
            Console.WriteLine("".PadRight(OptionPadding) + "   Right/Left Arrow Key Can Only Be Used When This Text Appears");
            Console.WriteLine("".PadRight(OptionPadding) + "   USE RIGHT AND LEFT ARROW KEY TO SCROLL BETWEEN PAGES AND PRESS ESCAPE TO GO BACK\n");
            Console.WriteLine("".PadRight(OptionPadding) + "3. Enter Key - Select The Option With Cursor\n");
            Console.WriteLine("".PadRight(OptionPadding) + "4. Backspace Key - Go Back To Last Menu OR Exit Current Menu\n");
            Console.WriteLine("".PadRight(OptionPadding) + "5. Number Keys - Select Option Corresponding to Key Presseds\n");

            PrintConfirmationDialog(new List<string> { });
        }
    }
}
