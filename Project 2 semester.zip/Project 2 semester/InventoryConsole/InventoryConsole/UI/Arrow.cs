﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace InventoryConsole.UI
{
    class Arrow : Window
    {
        private int _arrowX;
        private int _arrowY;
        private int _fixedY;
        private int _offset;
        private int _numberOfOptions;
        private bool _canScroll;
        private bool _canEscape;

        public Arrow(int numberOfOptions, int offset = 1, bool canScroll = false, bool canEscape = false)
        {
            _arrowX = OptionPadding;
            _arrowY = Console.CursorTop;
            _fixedY = _arrowY;
            _offset = offset;
            _numberOfOptions = numberOfOptions;
            _canScroll = canScroll;
            _canEscape = canEscape;
        }

        private void Display()
        {
            Console.SetCursorPosition(_arrowX, _arrowY);
            Console.Write(">");
        }

        private void Remove()
        {
            Console.SetCursorPosition(_arrowX, _arrowY);
            Console.Write(" ");
        }

        public int Select()
        {
            _arrowY = _fixedY;
            this.Display();
            ConsoleKeyInfo key;
            while (true)
            {
                key = Console.ReadKey(true);
                if (key.Key == ConsoleKey.DownArrow)
                {
                    this.Remove();
                    _arrowY += _offset;
                    if (_arrowY > _fixedY + _offset * (_numberOfOptions - 1))
                    {
                        _arrowY = _fixedY;
                    }
                    this.Display();
                }
                else if (key.Key == ConsoleKey.UpArrow)
                {
                    this.Remove();
                    _arrowY -= _offset;
                    if (_arrowY < _fixedY)
                    {
                        _arrowY = _fixedY + _offset * (_numberOfOptions - 1);
                    }
                    this.Display();
                }
                else if (key.Key == ConsoleKey.Enter)
                {
                    break;
                }
                else if (key.Key == ConsoleKey.Backspace)
                {
                    this.Remove();
                    _arrowY = _fixedY + _offset * (_numberOfOptions - 1);
                    this.Display();
                    Thread.Sleep(80);
                    return _numberOfOptions - 1;
                }
                else if (key.KeyChar >= 49 && key.KeyChar <= 59)
                {
                    int keyDiff = key.KeyChar - 48;
                    this.Remove();
                    _arrowY = _fixedY + _offset * (keyDiff - 1);
                    this.Display();
                    Thread.Sleep(80);
                    break;
                }
                if (_canScroll)
                {
                    if (key.Key == ConsoleKey.RightArrow)
                    {
                        this.Remove();
                        return -1;
                    }
                    else if (key.Key == ConsoleKey.LeftArrow)
                    {
                        this.Remove();
                        return -2;
                    }

                }
                if (_canEscape)
                {
                    if (key.Key == ConsoleKey.Escape)
                    {
                        this.Remove();
                        return -3;
                    }
                }
            }
            return ((_arrowY - _fixedY) / _offset);
        }

        public int NumberOfOptions
        {
            set => _numberOfOptions = value;
        }
    }
}
