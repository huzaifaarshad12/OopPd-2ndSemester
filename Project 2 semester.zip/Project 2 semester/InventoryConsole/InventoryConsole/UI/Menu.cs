﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace InventoryConsole.UI
{
    class Menu : Window
    {
        private List<List<string>> _texts;
        private int _outerLength;
        private int _innerLength;
        private int _outerLengthOffset;
        private int _startingIndex;
        private int _numberOfOptions;
        private bool _canEscape;
        private Arrow _arrow;

        public Menu(List<List<string>> texts, bool canEscape = false)
        {
            _texts = texts;
            _outerLength = texts.Count;
            _innerLength = texts[0].Count;
            _canEscape = canEscape;
            SetArrow();
        }

        public int Initialize()
        {
            int option;
            int y = Console.CursorTop;
            do
            {
                this.Print();
                option = _arrow.Select();
                if (option == -1)
                {
                    _startingIndex = (_startingIndex + _outerLengthOffset > _outerLength) ? _startingIndex : _startingIndex + _outerLengthOffset;
                    _arrow.NumberOfOptions = (_outerLengthOffset + _startingIndex > _outerLength) ? _outerLength - _startingIndex : _numberOfOptions;
                    Clear(y);
                }
                else if (option == -2)
                {
                    _startingIndex = (_startingIndex - _outerLengthOffset < 0) ? 0 : _startingIndex - _outerLengthOffset;
                    _arrow.NumberOfOptions = _numberOfOptions;
                    Clear(y);
                }
                else if (option == -3)
                {
                    return -1;
                }
            }
            while (option == -1 || option == -2);
            return option + _startingIndex;
        }

        private void Print()
        {
            int endingIndex = (_startingIndex + _outerLengthOffset > _outerLength) ? _outerLength : _startingIndex + _outerLengthOffset;
            for (int i = _startingIndex; i < endingIndex; i++)
            {
                for (int j = 0; j < _texts[i].Count; j++)
                {
                    Console.WriteLine("".PadRight(OptionPadding + 3) + _texts[i][j]);
                }
                if (_innerLength != 1)
                {
                    Console.WriteLine();
                }
            }
        }

        private void PrintScrollableInfo()
        {
            int originalY = Console.CursorTop;
            int x = (Width - 80) / 2;
            int y = Height - 1;
            Console.SetCursorPosition(x, y);
            Console.Write("USE RIGHT AND LEFT ARROW KEY TO SCROLL BETWEEN PAGES AND PRESS ESCAPE TO GO BACK");
            Console.SetCursorPosition(0, originalY);
        }

        private void PrintEscapeableInfo()
        {
            int originalY = Console.CursorTop;
            int x = (Width - 23) / 2;
            int y = Height - 1;
            Console.SetCursorPosition(x, y);
            Console.Write("PRESS ESCAPE TO GO BACK");
            Console.SetCursorPosition(0, originalY);
        }

        private void SetArrow()
        {
            bool canScroll = false;
            _numberOfOptions = _outerLength;
            _outerLengthOffset = _outerLength;
            int spacePerOption = (_innerLength == 1) ? _innerLength : _innerLength + 1;
            int optionsPerScreen = (Height - Console.CursorTop - 3) / spacePerOption;
            if (_outerLength > optionsPerScreen)
            {
                PrintScrollableInfo();
                canScroll = true;
                _canEscape = true;
                _outerLengthOffset = optionsPerScreen;
                _numberOfOptions = optionsPerScreen;
            }
            else if (_canEscape)
            {
                PrintEscapeableInfo();
            }
            _arrow = new Arrow(_numberOfOptions, (_innerLength == 1) ? _innerLength : _innerLength + 1, canScroll, _canEscape);
        }

        private void Clear(int startingY)
        {
            Console.SetCursorPosition(0, startingY);
            for (int i = startingY; i < Height - 1; i++)
            {
                Console.Write("".PadRight(Width));
            }
            Console.SetCursorPosition(0, startingY);
        }
    }
}
