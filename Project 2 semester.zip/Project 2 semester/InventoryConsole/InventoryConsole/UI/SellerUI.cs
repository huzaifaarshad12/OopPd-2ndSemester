﻿using Dll.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace InventoryConsole.UI
{
    class SellerUI : Window
    {
        public static int Menu()
        {
            PrintComponent("Seller");
            List<List<string>> options = new List<List<string>>
            {
                new List<string> { "Add Item to Market Place" },
                new List<string> { "View Your Items" },
                new List<string> { "Update Your Item Details" },
                new List<string> { "Remove Item From Market Place" },
                new List<string> { "View Stats About Your Items" },
                new List<string> { "Log Out" }
            };
            Menu menu = new Menu(options);
            return menu.Initialize();
        }

        public static Item CreateItem(string sellerName)
        {
            PrintComponent("Seller > Add Item");
            Console.Write("".PadRight(OptionPadding) + "Item Name: ");
            string name = Console.ReadLine();
            Console.Write("".PadRight(OptionPadding) + "Item Description: ");
            string description = Console.ReadLine();
            Console.Write("".PadRight(OptionPadding) + "Item Price: ");
            double price = double.Parse(Console.ReadLine());
            Console.Write("".PadRight(OptionPadding) + "Item Quantity: ");
            int quantity = int.Parse(Console.ReadLine());
            Item item = new Item(name, description, price, quantity, sellerName);
            PrintConfirmationDialog(new List<string> { "Item Added Successfully!!!" });
            return item;
        }

        public static void UpdateItem(Item item)
        {
            PrintComponent("Seller > Update Item > " + item.Name);
            Console.WriteLine("".PadRight(OptionPadding) + "Select Attribute to Update: ");
            int y = Console.CursorTop;
            string updatedAttribute;
            List<List<string>> options = new List<List<string>>
            {
                new List<string> { "Item Name" },
                new List<string> { "Item Description" },
                new List<string> { "Item Price" },
                new List<string> { "Add More Stock" },
                new List<string> { "Go Back" },
            };
            Menu menu = new Menu(options);
            int option = menu.Initialize();
            Console.SetCursorPosition(0, y + 7);
            if (option == 0)
            {
                Console.Write("".PadRight(OptionPadding) + "Item Name: ");
                string name = Console.ReadLine();
                item.Name = name;
                updatedAttribute = "Name";
            }
            else if (option == 1)
            {
                Console.Write("".PadRight(OptionPadding) + "Item Description: ");
                string description = Console.ReadLine();
                item.Description = description;
                updatedAttribute = "Description";
            }
            else if (option == 2)
            {
                Console.Write("".PadRight(OptionPadding) + "Item Price: ");
                double price = double.Parse(Console.ReadLine());
                item.Price = price;
                updatedAttribute = "Price";
            }
            else if (option == 3)
            {
                Console.Write("".PadRight(OptionPadding) + "Additional Stock: ");
                int stock = int.Parse(Console.ReadLine());
                item.Quantity += stock;
                updatedAttribute = "Quantity";
            }
            else
            {
                return;
            }
            PrintConfirmationDialog(new List<string> { "Item " + updatedAttribute + " Updated Successfully!!!" });
        }

        public static bool RemoveItem(Item item)
        {
            PrintComponent("Seller > Remove Item > " + item.Name);
            Console.WriteLine("".PadRight(OptionPadding) + "Are You Sure You want to remove " + item.Name + " from Marketplace?");
            List<List<string>> options = new List<List<string>>
            {
                new List<string> { "Yes" },
                new List<string> { "Cancel" }
            };
            Menu menu = new Menu(options);
            int option = menu.Initialize();
            if (option == 0)
            {
                Console.SetCursorPosition(0, Console.CursorTop + 3);
                PrintConfirmationDialog(new List<string> { "Item Removed Successfully!!!" });
            }
            return option == 0;
        }

        public static void PrintStats(List<Item> sellerItems)
        {
            PrintComponent("Seller > View Stats");
            if (sellerItems == null || sellerItems.Count == 0)
            {
                PrintConfirmationDialog(new List<string> { "NO ITEMS FOUND" });
                return;
            }
            int count = 1;
            List<List<string>> items = new List<List<string>>();
            foreach (var item in sellerItems)
            {
                List<string> currentItem = new List<string>
                {
                    string.Format("{0} - \"{1}\"", (count++).ToString(), item.Name),
                    string.Format("Remaining Item: {0}", item.Quantity.ToString()),
                    string.Format("Sold Item: {0}", item.Sold)
                };
                items.Add(currentItem);
            }
            Menu menu = new Menu(items, true);
            int option;
            do
            {
                option = menu.Initialize();
            }
            while (option != -1);
        }

        public static int MiniMenu()
        {
            List<List<string>> options = new List<List<string>>
            {
                new List<string> { "Update Item Details" },
                new List<string> { "Remove Item From Market Place" },
                new List<string> { "Go Back" }
            };
            Menu menu = new Menu(options);
            return menu.Initialize();
        }
    }
}
