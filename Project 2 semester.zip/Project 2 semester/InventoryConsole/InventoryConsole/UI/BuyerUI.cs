﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dll.BL;

namespace InventoryConsole.UI
{
    class BuyerUI : Window
    {
        public static int Menu()
        {
            PrintComponent("Buyer");
            List<List<string>> options = new List<List<string>>
            {
                new List<string> { "Visit Market Place" },
                new List<string> { "Search for Product" },
                new List<string> { "View Shopping Cart" },
                new List<string> { "Checkout All Items" },
                new List<string> { "Track Your Order" },
                new List<string> { "Notifications" },
                new List<string> { "Log Out" }
            };
            Menu menu = new Menu(options);
            return menu.Initialize();
        }

        public static int MiniMenu()
        {
            List<List<string>> options = new List<List<string>>
            {
                new List<string> { "Add To Cart" },
                new List<string> { "Buy Now" },
                new List<string> { "Go Back" }
            };
            Menu menu = new Menu(options);
            return menu.Initialize();
        }

        public static string SearchItem()
        {
            PrintComponent("Buyer > Search Market Place");
            Console.Write("".PadRight(OptionPadding) + "Search Query: ");
            string itemName = Console.ReadLine();
            Console.WriteLine();
            return itemName;
        }

        public static Order AddToCart(Item item)
        {
            PrintComponent("Buyer > Add To Cart > " + item.Name);
            Console.WriteLine("".PadRight(OptionPadding) + string.Format("Adding {0} to Shopping Cart", item.Name));
            Console.WriteLine();
            Console.Write("".PadRight(OptionPadding) + "Item Quantity: ");
            int itemQuantity = int.Parse(Console.ReadLine());
            if (itemQuantity > item.Quantity)
            {
                PrintConfirmationDialog(new List<string> { "Item Quantity Out Of Range", string.Format("Item Quantity can be from 1-{0}", item.Quantity) });
                return AddToCart(item);
            }
            return new Order(item, itemQuantity);
        }

        public static CheckOut PlaceOrder(Item item)
        {
            PrintComponent("Buyer > Place Order > " + item.Name);
            Console.WriteLine("".PadRight(OptionPadding) + string.Format("Ordering {0}", item.Name));
            Console.WriteLine();
            Console.Write("".PadRight(OptionPadding) + "Item Quantity: ");
            int itemQuantity = int.Parse(Console.ReadLine());
            if (itemQuantity > item.Quantity)
            {
                PrintConfirmationDialog(new List<string> { "Item Quantity Out Of Range", string.Format("Item Quantity can be from 1-{0}", item.Quantity) });
                return PlaceOrder(item);
            }
            Order order = new Order(item, itemQuantity);
            return new CheckOut(order);
        }

        public static int DisplayCart(List<Order> orders)
        {
            PrintComponent("Buyer > Shopping Cart");
            if (orders == null || orders.Count == 0)
            {
                PrintConfirmationDialog(new List<string> { "NO ITEMS FOUND" });
                return -1;
            }
            List<List<string>> texts = new List<List<string>>();
            foreach (Order order in orders)
            {
                Item item = order.Item;
                var currentItem = new List<string>
                {
                    string.Format($"{order.Quantity}x {item.Name}"),
                    string.Format($"Total Price: PKR: {order.TotalPrice()}"),
                    string.Format($"Seller: {item.Seller}")
                };
                texts.Add(currentItem);
            }

            Menu menu = new Menu(texts, true);
            return menu.Initialize();
        }

        public static int DisplayCartItem(Order order)
        {
            PrintComponent($"Buyer > Shopping Cart > {order.Item.Name}");
            Console.WriteLine("".PadRight(OptionPadding) + $"Item Name: {order.Item.Name}");
            Console.WriteLine("".PadRight(OptionPadding) + $"Item Seller: {order.Item.Seller}");
            Console.WriteLine("".PadRight(OptionPadding) + $"Item Quantity: {order.Quantity}");
            Console.WriteLine("".PadRight(OptionPadding) + $"Item Price Per Unit: PKR {order.Item.Price}");
            Console.WriteLine("".PadRight(OptionPadding) + $"Total Price: PKR {order.TotalPrice()}");
            Console.WriteLine();

            List<List<string>> texts = new List<List<string>> {
                new List<string>() { "Checkout Item" },
                new List<string>() { "Remove from Cart" },
                new List<string>() { "Go Back" }
            };
            int y = Console.CursorTop;
            Menu menu = new Menu(texts);
            int option = menu.Initialize();
            Console.SetCursorPosition(0, y + 4);
            if (option == 0)
            {
                PrintConfirmationDialog(new List<string> { $"{order.Item.Name} Checked Out Successfully!!!" });
            }
            else if (option == 1)
            {
                PrintConfirmationDialog(new List<string> { $"{order.Item.Name} Removed From Cart Successfully!!!" });
            }
            return option;
        }

        public static int CheckOutAllItems()
        {
            PrintComponent("Buyer > Shopping Cart > Check Out All");
            Console.WriteLine("".PadRight(OptionPadding) + "Do You Want to Check Out All Cart Items?");
            Console.WriteLine();
            int y = Console.CursorTop;
            int option = new Menu(new List<List<string>>
            {
                new List<string>() { "Yes" },
                new List<string>() { "Cancel" }
            }).Initialize();
            Console.SetCursorPosition(0, y + 3);
            if (option == 0)
            {
                PrintConfirmationDialog(new List<string> { "All Items Checked Out Successfully!!!" });
            }

            return option;
        }

        public static int DisplayCheckOuts(List<CheckOut> checkOuts)
        {
            PrintComponent("Buyer > Track Order");
            if (checkOuts == null || checkOuts.Count == 0)
            {
                PrintConfirmationDialog(new List<string> { "NO ITEMS FOUND" });
                return -1;
            }
            List<List<string>> texts = new List<List<string>>();
            foreach (CheckOut checkout in checkOuts)
            {
                var currentItem = new List<string>
                {
                    string.Format($"{checkout.Order.Quantity}x {checkout.Order.Item.Name}"),
                    string.Format($"{checkout.Id} - {checkout.RemainingDays()} Days"),
                    string.Format($"Total Price: PKR: {checkout.Order.TotalPrice()}")
                };
                texts.Add(currentItem);
            }

            Menu menu = new Menu(texts, true);
            return menu.Initialize();
        }

        public static int DisplayCheckOutItem(CheckOut checkOut)
        {
            PrintComponent($"Buyer > Shopping Cart > {checkOut.Order.Item.Name}");
            Console.WriteLine("".PadRight(OptionPadding) + $"Item Name: {checkOut.Order.Item.Name}");
            Console.WriteLine("".PadRight(OptionPadding) + $"Item Seller: {checkOut.Order.Item.Seller}");
            Console.WriteLine("".PadRight(OptionPadding) + $"Tracking Code: {checkOut.Id}");
            Console.WriteLine("".PadRight(OptionPadding) + $"Ordered Date: {checkOut.OrderDate:yyyy-MM-dd}");
            Console.WriteLine("".PadRight(OptionPadding) + $"Item Arrival Days Left: {checkOut.RemainingDays()}");
            Console.WriteLine("".PadRight(OptionPadding) + $"Item Quantity: {checkOut.Order.Quantity}");
            Console.WriteLine("".PadRight(OptionPadding) + $"Item Price Per Unit: PKR {checkOut.Order.Item.Price}");
            Console.WriteLine("".PadRight(OptionPadding) + $"Total Price: PKR {checkOut.Order.TotalPrice()}");
            Console.WriteLine();

            List<List<string>> texts = new List<List<string>> {
                new List<string>() { "Cancel Order" },
                new List<string>() { "Go Back" }
            };
            int y = Console.CursorTop;
            Menu menu = new Menu(texts);
            int option = menu.Initialize();
            Console.SetCursorPosition(0, y + 4);
            if (option == 0)
            {
                PrintConfirmationDialog(new List<string> { "Order Cancelled Successfully!!!" });
            }
            return option;
        }
    }
}
