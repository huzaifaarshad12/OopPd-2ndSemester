﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dll.BL;
using InventoryConsole.Controller;
using Dll.DL;
using InventoryConsole.UI;

namespace InventoryConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            UserCRUD.LoadUsers();
            User user;
            Console.CursorVisible = false;
            Window.Initialize();
            do
            {
                user = MainController.Start();
                if (user != null)
                {
                    if (user is Buyer buyer)
                    {
                        BuyerController.Start(buyer);
                    }
                    else if (user is Seller seller)
                    {
                        SellerController.Start(seller);
                    }
                }
            } while (true);
        }
    }
}
