﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dll.BL;


namespace Dll.DLInterfaces
{
    internal interface IItemCRUDdB
    {
        bool addItem(Item item);
        void delItem(Item item);
        void updateItem(Item item);
        DataTable getItemData();
    }
}
