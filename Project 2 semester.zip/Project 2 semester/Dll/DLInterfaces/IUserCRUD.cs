﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dll.BL;

namespace Dll.DLInterfaces
{
    internal interface IUserCRUD
    {
        User SignIn(User user);
        bool SignUp(User user);
        bool changePassord(string username, string oldPass, string newPass);
        List<User> getAllUsers();
    }
}



