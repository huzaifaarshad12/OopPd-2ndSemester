﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dll.BL;
using Dll.DLInterfaces;
using Dll.Utilities;



namespace Dll.DL
{
    internal class ItemCRUDdB : IItemCRUDdB
    {
        public string connectionString = Utilities.Utility.getconnString();
        static ItemCRUDdB instance;

        private ItemCRUDdB(string connectionString)
        {
            this.connectionString = connectionString;
        }
        public static ItemCRUDdB getInstance(string connectionString)
        {
            if (instance == null)
            {
                instance = new ItemCRUDdB(connectionString);
            }
            return instance;
        }

        public bool addItem(Item item)
        {
            if (!(ItemCRUDdB.validateItem(item, connectionString)))
            {
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                string query = String.Format("INSERT INTO ItemTbl(itemName,description,price,quantity,sellerName) VALUES('{0}', '{1}', '{2}' , '{3}' , '{4}')", item.Name, item.Description, item.Price, item.Quantity, item.Seller);
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();
                connection.Close();
                return true;
            }
            return false;
        }

        

        public void delItem(Item item)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            string query = String.Format("DELETE FROM ItemTbl WHERE itemName = '{0}'", item.Name);
            SqlCommand command = new SqlCommand(query, connection);
            command.ExecuteNonQuery();
            connection.Close();
        }

        public DataTable getItemData()
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select itemName AS 'ItemName', description AS 'Description', price AS 'Price',quantity AS 'Quantity', sellerName AS SellerName from ItemTbl where itemName = @itemName ", con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable table = new DataTable();
            adapter.Fill(table);
            con.Close();
            return table;
        }

        public void updateItem(Item item)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            string query = String.Format(@"UPDATE ItemTbl set itemName =@itemName, description =@description, price =@price, quantity =@quantity, sellerName =@sellerName WHERE itemName = @itemName");

            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@itemName", item.Name);
            command.Parameters.AddWithValue("@description", item.Description);
            command.Parameters.AddWithValue("@price", item.Price);
            command.Parameters.AddWithValue("@quantity", item.Quantity);
            command.Parameters.AddWithValue("@sellerName", item);
            command.ExecuteNonQuery();
            connection.Close();
        }
        public static bool validateItem(Item item, string connectionString)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            string searchQuery = String.Format("Select * from ItemTbl where username = '{0}'", item.Name);
            SqlCommand command = new SqlCommand(searchQuery, connection);
            SqlDataReader data = command.ExecuteReader();
            bool check = data.Read();
            connection.Close();
            return check;

        }
    }

}

