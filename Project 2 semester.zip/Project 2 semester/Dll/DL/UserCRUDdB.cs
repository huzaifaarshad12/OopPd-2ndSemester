﻿using Dll.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dll.DLInterfaces;
using System.Data.SqlClient;
using System.Data;
using Dll.BL;
using System.Threading;


namespace Dll.DL
{
    internal class UserCRUDdB : IUserCRUD
    {
        public string connectionString = Utility.getconnString();
        static UserCRUDdB instance;
        private UserCRUDdB(string connectionString)
        {
            this.connectionString = connectionString;
        }
        public static UserCRUDdB getInstance(string connectionString)
        {
            if (instance == null)
            {
                instance = new UserCRUDdB(connectionString);
            }
            return instance;
        }
        public User SignIn(User user)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            string searchQuery = String.Format("Select * from User where username = '{0}' and password = '{1}'", user.UserName, user.Password);
            SqlCommand command = new SqlCommand(searchQuery, connection);
            SqlDataReader data = command.ExecuteReader();
            if (data.Read())
            {
                string username = data.GetString(0);
                string password = data.GetString(1);
                string role = data.GetString(2);

                User user1 = new User(username, password, role);
                connection.Close();
                return user1;
            }
            connection.Close();
            return null;
        }
        public static bool validateUser(User user, string connectionString)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            string searchQuery = String.Format("Select * from User where username = '{0}'", user.UserName);
            SqlCommand command = new SqlCommand(searchQuery, connection);
            SqlDataReader data = command.ExecuteReader();
            bool check = data.Read();
            connection.Close();
            return check;

        }

        public bool SignUp(User user)
        {
            if (!validateUser(user, connectionString))
            {
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                string query = String.Format("INSERT INTO User(username,password,fullName) VALUES('{0}','{1}','{2}')", user.UserName, user.Password, user.FullName);
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();
                connection.Close();
                return true;
            }

            return false;
        }
        public bool addEmployee(SellerUser user)
        {
            if (!validateUser(user, connectionString))
            {
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                string query = String.Format("INSERT INTO Users VALUES('{0}', '{1}', '{2}')", user.UserName, user.Password, user.FullName);
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();
                connection.Close();
                return true;
            }
            return false;
        }
     

        public DataTable getSellerData()
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select username AS 'Username',password AS 'Password', fullname AS 'FullName', from User where role = 'Buyer' OR role ='Seller' ", con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable table = new DataTable();
            adapter.Fill(table);
            con.Close();
            return table;
        }
        public List<User> getAllUsers()
        {
            List<User> usersList = new List<User>();
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            string query = "SELECT * FROM User";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                User user = new User(reader.GetString(1), reader.GetString(2), reader.GetString(3));
                usersList.Add(user);
            }
            connection.Close();
            return usersList;
        }
        private bool validatePassword(User user, string connectionString)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            string query = String.Format("SELECT * FROM User WHERE username = '{0}' AND password = '{1}'", user.UserName, user.Password);
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                connection.Close();
                return true;
            }
            connection.Close();
            return false;
        }
        public bool changePassord(string username, string oldPass, string newPass)
        {
            User user = new User(username, oldPass);
            if (validatePassword(user, connectionString))
            {
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                string query = String.Format("UPDATE Users SET password = '{0}' WHERE username = '{1}'", newPass, username);
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();
                connection.Close();
                return true;
            }
            return false;
        }
        
    }
}
