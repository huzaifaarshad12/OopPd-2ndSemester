﻿using Dll.BL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dll.DL
{
    public class SellerCRUD
    {
        public static void WriteSeller(SellerUser seller, StreamWriter writer)
        {
            writer.Write($"S;{seller.FullName};{seller.UserName};{seller.Password},");
            foreach (var item in seller.Items)
            {
                writer.Write($"{item.Name};{item.Description};{item.Price};{item.Quantity};{item.Sold};{item.Seller},");
            }
            writer.WriteLine();
        }

        public static User LoadSeller(string buffer)
        {
            var data = buffer.Split(',');
            var userData = data[0].Split(';');
            SellerUser seller = new SellerUser(userData[1], userData[2], userData[3]);
            for (int i = 1; i < data.Length; i++)
            {
                if (data[i] != "")
                {
                    Item item = ItemCRUD.LoadItem(data[i]);
                    seller.AddItem(item);
                }
            }
            return seller;
        }
    }
}
