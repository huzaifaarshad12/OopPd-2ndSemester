﻿using Dll.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dll.DL
{
    public class ItemCRUD
    {
        public static List<Item> Items = new List<Item>();

        public SellerCRUD SellerCRUD
        {
            get => default;
            set
            {
            }
        }

        public BuyerCRUD BuyerCRUD
        {
            get => default;
            set
            {
            }
        }

        public static Item LoadItem(string buffer)
        {
            var itemData = buffer.Split(';');
            Item item = new Item(itemData[0], itemData[1], double.Parse(itemData[2]), int.Parse(itemData[3]), int.Parse(itemData[4]), itemData[5]);
            Items.Add(item);
            return item;
        }

        public static Item FindItem(string itemName)
        {
            foreach (var item in Items)
            {
                if (item.Name == itemName)
                {
                    return item;
                }
            }
            return null;
        }
    }
}
