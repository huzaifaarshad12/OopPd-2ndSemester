﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dll.BL;

namespace Dll.DL
{
    public class UserCRUD
    {
        private static List<User> _users = new List<User>();


        public static void AddUser(User user)
        {
            _users.Add(user);
        }

        public static User FindUser(string userName, string password)
        {
            return _users.Find(user => user.UserName == userName && user.Password == password);
        }

        public static void RewriteUsers()
        {
          string path = "../../Data/Users.csv";
            StreamWriter writer = new StreamWriter(path);
            foreach (var user in _users)
            {
                if (user is SellerUser seller)
                {
                    SellerCRUD.WriteSeller(seller, writer);
                }
                else if (user is BuyerUser buyer)
                {
                    BuyerCRUD.WriteBuyer(buyer, writer);
                }
            }
            writer.Flush();
            writer.Close();
        }

        public static void LoadUsers()
        {
            string path = "../../Data/Users.csv";
            

            if (File.Exists(path))
            {
                StreamReader reader = new StreamReader(path);
                do
                {
                    string line = reader.ReadLine();
                    if (line[0] == 'S')
                    {
                        _users.Add(SellerCRUD.LoadSeller(line));
                    }
                    else if (line[0] == 'B')
                    {
                        _users.Add(BuyerCRUD.LoadBuyer(line));
                    }
                }
                while (!reader.EndOfStream);
                reader.Close();
            }
        }

        public static List<User> Users { get => _users; }

        public SellerCRUD SellerCRUD
        {
            get => default;
            set
            {
            }
        }

        public BuyerCRUD BuyerCRUD
        {
            get => default;
            set
            {
            }
        }
    }
}
