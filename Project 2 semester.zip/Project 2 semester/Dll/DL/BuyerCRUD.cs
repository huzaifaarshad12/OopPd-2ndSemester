﻿using Dll.BL;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dll.DL
{
    public class BuyerCRUD
    {
        public static void WriteBuyer(BuyerUser buyer, StreamWriter writer)
        {
            writer.Write($"B;{buyer.FullName};{buyer.UserName};{buyer.Password},");
            foreach (var order in buyer.Cart.Orders)
            {
                writer.Write($"{order.Quantity}-{order.Item.Name};");
            }
            writer.Write(',');
            foreach (var checkout in buyer.CheckOuts)
            {
                writer.Write($"{checkout.Id}-{checkout.Order.Quantity}-{checkout.Order.Item.Name}-{checkout.OrderDate:yyyy/MM/dd}-{checkout.ArrivalDate:yyyy/MM/dd};");
            }
            writer.WriteLine();
        }

        public static User LoadBuyer(string buffer)
        {
            var data = buffer.Split(',');
            var userData = data[0].Split(';');
            BuyerUser buyer = new BuyerUser(userData[1], userData[2], userData[3]);
            if (data[1] != "")
            {
                var orderData = data[1].Split(';');
                foreach (var oData in orderData)
                {
                    if (oData != "")
                    {
                        var currentOrder = oData.Split('-');
                        int quantity = int.Parse(currentOrder[0]);
                        Item item = ItemCRUD.FindItem(currentOrder[1]);
                        Order order = new Order(item, quantity);
                        buyer.AddOrder(order);
                    }
                }
            }
            if (data[2] != "")
            {
                var checkoutData = data[2].Split(';');
                foreach (var cData in checkoutData)
                {
                    if (cData != "")
                    {
                        var currentCheckout = cData.Split('-');
                        int id = int.Parse(currentCheckout[0]);
                        int quantitiy = int.Parse(currentCheckout[1]);
                        Item item = ItemCRUD.FindItem(currentCheckout[2]);
                        DateTime orderDate = DateTime.ParseExact(currentCheckout[3], "yyyy/MM/dd", null);
                        DateTime arrivalDate = DateTime.ParseExact(currentCheckout[4], "yyyy/MM/dd", null);
                        Order order = new Order(item, quantitiy);
                        CheckOut checkOut = new CheckOut(id, order, orderDate, arrivalDate);
                        buyer.AddCheckOut(checkOut);
                    }
                }
            }
            return buyer;
        }
    }
}
