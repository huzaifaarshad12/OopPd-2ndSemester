﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dll.BL
{
    public class SellerUser : User
    {
        private List<Item> _items;

        public SellerUser(string fullName, string userName, string password) : base(fullName, userName, password)
        {
            _items = new List<Item>();
        }

        public void AddItem(Item item)
        {
            _items.Add(item);
        }

        public void RemoveItem(int index)
        {
            _items.RemoveAt(index);
        }

        public void RemoveItem(Item item)
        {
            _items.Remove(item);
        }

        public Item GetItem(int index)
        {
            return _items[index];
        }
        public List<Item> Items { get => _items;  }
    }
}
