﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dll.BL
{
    public class User
    {
        private string _userName;
        private string _password;
        private string _fullName;

        public User(string fullName, string userName, string password)
        {
            _userName = userName;
            _password = password;
            _fullName = fullName;
        }
        public User(string userName, string password)
        {
            this._userName = userName;
            this._password = password;
        }

        public string UserName { get => _userName; }
        public string Password { get => _password; }
        public string FullName { get => _fullName; }
    }
}
