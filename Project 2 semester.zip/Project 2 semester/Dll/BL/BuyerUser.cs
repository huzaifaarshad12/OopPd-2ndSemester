﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dll.BL
{
    public class BuyerUser : User
    {
        private Cart _cart;
        private List<CheckOut> _checkOuts;

        public BuyerUser(string fullName, string userName, string password) : base(fullName, userName, password)
        {
            _cart = new Cart();
            _checkOuts = new List<CheckOut>();
        }

        public void AddOrder(Order order)
        {
            _cart.AddOrder(order);
        }

        public void AddCheckOut(CheckOut checkOut)
        {
            _checkOuts.Add(checkOut);
        }

        public void CheckOutItem(int cartIndex)
        {
            Order order = _cart.Orders[cartIndex];
            _cart.RemoveFromCart(cartIndex);
            CheckOut checkout = new CheckOut(order);
            AddCheckOut(checkout);
        }

        public void CheckOutAll()
        {
            for (int i = 0; i < _cart.Orders.Count; i++)
            {
                CheckOutItem(i);
            }
            for (int i = 0; i < _cart.Orders.Count; i++)
            {
                CheckOutItem(i);
            }
        }

        public void RemoveFromCart(int cartIndex)
        {
            Item item = _cart.Orders[cartIndex].Item;
            item.Refund(_cart.Orders[cartIndex].Quantity);
            _cart.RemoveFromCart(cartIndex);
        }

        public void CancelOrder(int checkOutIndex)
        {
            Item item = CheckOuts[checkOutIndex].Order.Item;
            item.Refund(CheckOuts[checkOutIndex].Order.Quantity);
            CheckOuts.RemoveAt(checkOutIndex);
        }

        public Cart Cart { get => _cart; }
        public List<CheckOut> CheckOuts { get => _checkOuts; }
    }
}
