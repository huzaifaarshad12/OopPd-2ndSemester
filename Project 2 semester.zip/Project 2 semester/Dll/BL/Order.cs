﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dll.BL
{
    public class Order
    {
        private Item _item;
        private int _quantity;

        public Order(Item item, int quantity)
        {
            _item = item;
            _quantity = quantity;
        }

        public double TotalPrice()
        {
            return _quantity * _item.Price;
        }
        public int Quantity { get => _quantity; }
        public string ItemName { get => _item.Name; }
        public double ItemPrice { get => _item.Price; }
        [Browsable(false)]
        public Item Item { get => _item; }
    }
}
