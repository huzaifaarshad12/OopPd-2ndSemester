﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dll.BL
{
    public class Item
    {
        private string _name;
        private string _description;
        private double _price;
        private int _quantity;
        private int _sold;
        private string _seller;

        public Item(string name, string description, double price, int quantity, string seller)
        {
            _name = name;
            _description = description;
            _price = price;
            _quantity = quantity;
            _seller = seller;
            _sold = 0;
        }

        public Item(string name, string description, double price, int quantity, int sold, string seller)
        {
            _name = name;
            _description = description;
            _price = price;
            _quantity = quantity;
            _sold = sold;
            _seller = seller;
        }

        public string Name
        {
            get => _name;
            set => _name = value;
        }
        public string Description
        {
            get => _description;
            set => _description = value;
        }
        public double Price
        {
            get => _price;
            set => _price = value;
        }
        public int Quantity
        {
            get => _quantity;
            set => _quantity = value;
        }
        public string Seller { get => _seller; }
        public int Sold
        {
            get => _sold;
            set => _sold = value;
        }

        public void Purchase(int quantity)
        {
            _quantity -= quantity;
            _sold += quantity;
        }

        public void Refund(int quantity)
        {
            _quantity += quantity;
            _sold -= quantity;
        }
    }
}
