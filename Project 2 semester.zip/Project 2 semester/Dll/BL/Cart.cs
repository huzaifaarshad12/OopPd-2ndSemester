﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dll.BL
{
    public class Cart
    {
        private List<Order> _orders;

        public Cart()
        {
            _orders = new List<Order>();
        }

        public List<Order> Orders
        {
            get => _orders;
            set => _orders = value;
        }

        public void AddOrder(Order order)
        {
            _orders.Add(order);
        }

        public void RemoveFromCart(int cartIndex)
        {
            _orders.RemoveAt(cartIndex);
        }
    }
}
