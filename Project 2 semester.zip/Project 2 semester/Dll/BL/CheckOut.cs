﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dll.BL
{
    public class CheckOut
    {
        private int _id;
        private Order _order;
        private DateTime _orderDate;
        private DateTime _arrivalDate;

        public CheckOut(Order order)
        {
            _order = order;
            Random random = new Random();
            _id = random.Next(10001, 99999);
            _orderDate = DateTime.Now;
            _arrivalDate = _orderDate.AddDays(random.Next(1, 7));
        }

        public CheckOut(int id, Order order, DateTime orderDate, DateTime arrivalDate)
        {
            _id = id;
            _order = order;
            _arrivalDate = arrivalDate;
            _orderDate = orderDate;
        }

        public int RemainingDays()
        {
            TimeSpan difference = _arrivalDate - _orderDate;
            return difference.Days;
        }

        public int Id { get => _id; set => _id = value; }
        public int ArrivalDays { get => this.RemainingDays(); }
        public double ItemPrice { get => _order.ItemPrice; }
        public string ItemName { get => _order.ItemName; }
        public int Quantity { get => _order.Quantity; }
        [Browsable(false)]
        public Order Order { get => _order; set => _order = value; }
        [Browsable(false)]
        public DateTime OrderDate { get => _orderDate; set => _orderDate = value; }
        [Browsable(false)]
        public DateTime ArrivalDate { get => _arrivalDate; set => _arrivalDate = value; }
    }
}
