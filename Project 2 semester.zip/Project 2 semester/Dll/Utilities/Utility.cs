﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dll.Utilities
{
    internal class Utility
    {
        private static string connString = "Data Source=HUZAIFA-DELL;Initial Catalog=Dll;Integrated Security=True;";
        public static string getconnString()
        {
            return connString;
        }
    }
}
